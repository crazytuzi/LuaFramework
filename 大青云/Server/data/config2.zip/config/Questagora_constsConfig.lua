Questagora_constsConfig={
	['1']={
		['id'] = 1,
		['limit_day'] = 20,
		['refresh_time'] = 5,
		['quest_cd'] = 0,
		['refresh_cost'] = "10,5000",
		['gratis_times'] = 10,
		['quest_num'] = 6,
		['quest_limit'] = 2,
		['reward'] = "150800201,4",
		['rewarddaily'] = "151100041,3#151100051,3#151100061,3",
	},
};