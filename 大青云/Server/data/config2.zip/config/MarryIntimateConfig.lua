MarryIntimateConfig={
	['1']={
		['level'] = 1,
		['needIntimate'] = 400,
		['attrExtraPercent'] = 20,
	},
	['2']={
		['level'] = 2,
		['needIntimate'] = 1000,
		['attrExtraPercent'] = 40,
	},
	['3']={
		['level'] = 3,
		['needIntimate'] = 1800,
		['attrExtraPercent'] = 80,
	},
	['4']={
		['level'] = 4,
		['needIntimate'] = 3000,
		['attrExtraPercent'] = 140,
	},
	['5']={
		['level'] = 5,
		['needIntimate'] = 4200,
		['attrExtraPercent'] = 220,
	},
	['6']={
		['level'] = 6,
		['needIntimate'] = 5600,
		['attrExtraPercent'] = 320,
	},
	['7']={
		['level'] = 7,
		['needIntimate'] = 7500,
		['attrExtraPercent'] = 430,
	},
	['8']={
		['level'] = 8,
		['needIntimate'] = 9200,
		['attrExtraPercent'] = 550,
	},
	['9']={
		['level'] = 9,
		['needIntimate'] = 11400,
		['attrExtraPercent'] = 700,
	},
	['10']={
		['level'] = 10,
		['needIntimate'] = 13800,
		['attrExtraPercent'] = 900,
	},
};