ZhuoyuenumConfig={
	['0']={
		['quality'] = 0,
		['num'] = 0,
	},
	['1']={
		['quality'] = 1,
		['num'] = 0,
	},
	['2']={
		['quality'] = 2,
		['num'] = 0,
	},
	['3']={
		['quality'] = 3,
		['num'] = 0,
	},
	['4']={
		['quality'] = 4,
		['num'] = 0,
	},
	['5']={
		['quality'] = 5,
		['num'] = 1,
	},
	['6']={
		['quality'] = 6,
		['num'] = 2,
	},
	['7']={
		['quality'] = 7,
		['num'] = 3,
	},
};