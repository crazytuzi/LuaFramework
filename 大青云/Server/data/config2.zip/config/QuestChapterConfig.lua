QuestChapterConfig={
	['1']={
		['id'] = 1,
		['reward'] = "att,100#def,20",
	},
	['2']={
		['id'] = 2,
		['reward'] = "att,100#def,21",
	},
	['3']={
		['id'] = 3,
		['reward'] = "att,100#def,22",
	},
	['4']={
		['id'] = 4,
		['reward'] = "att,100#def,23",
	},
	['5']={
		['id'] = 5,
		['reward'] = "att,100#def,24",
	},
	['6']={
		['id'] = 6,
		['reward'] = "att,100#def,25",
	},
	['7']={
		['id'] = 7,
		['reward'] = "att,100#def,26",
	},
	['8']={
		['id'] = 8,
		['reward'] = "att,100#def,27",
	},
	['9']={
		['id'] = 9,
		['reward'] = "att,100#def,28",
	},
};