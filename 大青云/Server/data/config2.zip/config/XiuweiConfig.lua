XiuweiConfig={
	['1']={
		['id'] = 1,
		['init'] = 4000,
		['max_accumulate'] = 720000,
		['max_current'] = 72000,
		['times'] = 10000,
		['decrease'] = 1200,
		['lv_distance'] = 50,
	},
};