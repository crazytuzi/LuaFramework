DigongguildrewardConfig={
	['1']={
		['level'] = 1,
		['winReward1'] = 1000000,
		['winReward2'] = 200,
		['lostReward1'] = 1000000,
		['lostReward2'] = 200,
	},
	['2']={
		['level'] = 2,
		['winReward1'] = 2000000,
		['winReward2'] = 200,
		['lostReward1'] = 2000000,
		['lostReward2'] = 200,
	},
	['3']={
		['level'] = 3,
		['winReward1'] = 3000000,
		['winReward2'] = 200,
		['lostReward1'] = 3000000,
		['lostReward2'] = 200,
	},
	['4']={
		['level'] = 4,
		['winReward1'] = 4000000,
		['winReward2'] = 200,
		['lostReward1'] = 4000000,
		['lostReward2'] = 200,
	},
	['5']={
		['level'] = 5,
		['winReward1'] = 5000000,
		['winReward2'] = 200,
		['lostReward1'] = 5000000,
		['lostReward2'] = 200,
	},
};