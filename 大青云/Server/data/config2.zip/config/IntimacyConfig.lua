IntimacyConfig={
	['1']={
		['id'] = 1,
		['startVal'] = 0,
		['endVal'] = 999,
		['exp'] = 0,
		['gold'] = 0,
	},
	['2']={
		['id'] = 2,
		['startVal'] = 1000,
		['endVal'] = 2999,
		['exp'] = 20,
		['gold'] = 20,
	},
	['3']={
		['id'] = 3,
		['startVal'] = 3000,
		['endVal'] = 7999,
		['exp'] = 40,
		['gold'] = 40,
	},
	['4']={
		['id'] = 4,
		['startVal'] = 8000,
		['endVal'] = 15999,
		['exp'] = 50,
		['gold'] = 50,
	},
	['5']={
		['id'] = 5,
		['startVal'] = 16000,
		['endVal'] = 29999,
		['exp'] = 60,
		['gold'] = 60,
	},
	['6']={
		['id'] = 6,
		['startVal'] = 30000,
		['endVal'] = 999999999,
		['exp'] = 70,
		['gold'] = 70,
	},
};