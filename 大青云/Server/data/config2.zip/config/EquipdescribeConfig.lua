EquipdescribeConfig={
	['1']={
		['id'] = 1,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,112#def,56#hp,1122",
	},
	['2']={
		['id'] = 2,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,224#def,112#hp,2244",
	},
	['3']={
		['id'] = 3,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,449#def,224#hp,4488",
	},
	['4']={
		['id'] = 4,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,898#def,449#hp,8976",
	},
	['5']={
		['id'] = 5,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,1795#def,898#hp,17952",
	},
	['6']={
		['id'] = 6,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,3590#def,1795#hp,35904",
	},
	['7']={
		['id'] = 7,
		['quality'] = "5,6,7",
		['baseAttr'] = "att,7181#def,3590#hp,71808",
	},
};