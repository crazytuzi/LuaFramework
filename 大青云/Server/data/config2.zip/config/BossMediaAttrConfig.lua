BossMediaAttrConfig={
	['100']={
		['ID'] = 100,
		['star_attr'] = "att,100#def,50#hp,400#cri,30#defcri,30#dodge,30#hit,30#adddamagemonx,0.05#adddamagebossx,0.01",
	},
	['101']={
		['ID'] = 101,
		['star_attr'] = "att,124#def,62#hp,496#cri,36#defcri,36#dodge,36#hit,36#adddamagemonx,0.06#adddamagebossx,0.012",
	},
	['102']={
		['ID'] = 102,
		['star_attr'] = "att,148#def,74#hp,592#cri,44#defcri,44#dodge,44#hit,44#adddamagemonx,0.07#adddamagebossx,0.014",
	},
	['103']={
		['ID'] = 103,
		['star_attr'] = "att,172#def,86#hp,688#cri,50#defcri,50#dodge,50#hit,50#adddamagemonx,0.08#adddamagebossx,0.016",
	},
	['104']={
		['ID'] = 104,
		['star_attr'] = "att,196#def,98#hp,784#cri,58#defcri,58#dodge,58#hit,58#adddamagemonx,0.09#adddamagebossx,0.018",
	},
	['200']={
		['ID'] = 200,
		['star_attr'] = "att,220#def,110#hp,880#cri,66#defcri,66#dodge,66#hit,66#adddamagemonx,0.1#adddamagebossx,0.02",
	},
	['201']={
		['ID'] = 201,
		['star_attr'] = "att,264#def,132#hp,1056#cri,78#defcri,78#dodge,78#hit,78#adddamagemonx,0.11#adddamagebossx,0.022",
	},
	['202']={
		['ID'] = 202,
		['star_attr'] = "att,308#def,154#hp,1232#cri,92#defcri,92#dodge,92#hit,92#adddamagemonx,0.12#adddamagebossx,0.024",
	},
	['203']={
		['ID'] = 203,
		['star_attr'] = "att,352#def,176#hp,1408#cri,104#defcri,104#dodge,104#hit,104#adddamagemonx,0.13#adddamagebossx,0.026",
	},
	['204']={
		['ID'] = 204,
		['star_attr'] = "att,396#def,198#hp,1584#cri,118#defcri,118#dodge,118#hit,118#adddamagemonx,0.14#adddamagebossx,0.028",
	},
	['300']={
		['ID'] = 300,
		['star_attr'] = "att,440#def,220#hp,1760#cri,132#defcri,132#dodge,132#hit,132#adddamagemonx,0.15#adddamagebossx,0.03",
	},
	['301']={
		['ID'] = 301,
		['star_attr'] = "att,528#def,264#hp,2112#cri,158#defcri,158#dodge,158#hit,158#adddamagemonx,0.16#adddamagebossx,0.032",
	},
	['302']={
		['ID'] = 302,
		['star_attr'] = "att,616#def,308#hp,2464#cri,184#defcri,184#dodge,184#hit,184#adddamagemonx,0.17#adddamagebossx,0.034",
	},
	['303']={
		['ID'] = 303,
		['star_attr'] = "att,704#def,352#hp,2816#cri,210#defcri,210#dodge,210#hit,210#adddamagemonx,0.18#adddamagebossx,0.036",
	},
	['304']={
		['ID'] = 304,
		['star_attr'] = "att,792#def,396#hp,3168#cri,236#defcri,236#dodge,236#hit,236#adddamagemonx,0.19#adddamagebossx,0.038",
	},
	['400']={
		['ID'] = 400,
		['star_attr'] = "att,880#def,440#hp,3520#cri,264#defcri,264#dodge,264#hit,264#adddamagemonx,0.2#adddamagebossx,0.04",
	},
	['401']={
		['ID'] = 401,
		['star_attr'] = "att,1040#def,520#hp,4160#cri,312#defcri,312#dodge,312#hit,312#adddamagemonx,0.21#adddamagebossx,0.042",
	},
	['402']={
		['ID'] = 402,
		['star_attr'] = "att,1200#def,600#hp,4800#cri,360#defcri,360#dodge,360#hit,360#adddamagemonx,0.22#adddamagebossx,0.044",
	},
	['403']={
		['ID'] = 403,
		['star_attr'] = "att,1360#def,680#hp,5440#cri,408#defcri,408#dodge,408#hit,408#adddamagemonx,0.23#adddamagebossx,0.046",
	},
	['404']={
		['ID'] = 404,
		['star_attr'] = "att,1520#def,760#hp,6080#cri,456#defcri,456#dodge,456#hit,456#adddamagemonx,0.24#adddamagebossx,0.048",
	},
	['500']={
		['ID'] = 500,
		['star_attr'] = "att,1680#def,840#hp,6720#cri,504#defcri,504#dodge,504#hit,504#adddamagemonx,0.25#adddamagebossx,0.05",
	},
	['501']={
		['ID'] = 501,
		['star_attr'] = "att,2008#def,1004#hp,8032#cri,602#defcri,602#dodge,602#hit,602#adddamagemonx,0.26#adddamagebossx,0.052",
	},
	['502']={
		['ID'] = 502,
		['star_attr'] = "att,2336#def,1168#hp,9344#cri,700#defcri,700#dodge,700#hit,700#adddamagemonx,0.27#adddamagebossx,0.054",
	},
	['503']={
		['ID'] = 503,
		['star_attr'] = "att,2664#def,1332#hp,10656#cri,798#defcri,798#dodge,798#hit,798#adddamagemonx,0.28#adddamagebossx,0.056",
	},
	['504']={
		['ID'] = 504,
		['star_attr'] = "att,2992#def,1496#hp,11968#cri,896#defcri,896#dodge,896#hit,896#adddamagemonx,0.29#adddamagebossx,0.058",
	},
	['600']={
		['ID'] = 600,
		['star_attr'] = "att,3320#def,1660#hp,13280#cri,996#defcri,996#dodge,996#hit,996#adddamagemonx,0.3#adddamagebossx,0.06",
	},
	['601']={
		['ID'] = 601,
		['star_attr'] = "att,3872#def,1936#hp,15488#cri,1160#defcri,1160#dodge,1160#hit,1160#adddamagemonx,0.31#adddamagebossx,0.062",
	},
	['602']={
		['ID'] = 602,
		['star_attr'] = "att,4424#def,2212#hp,17696#cri,1326#defcri,1326#dodge,1326#hit,1326#adddamagemonx,0.32#adddamagebossx,0.064",
	},
	['603']={
		['ID'] = 603,
		['star_attr'] = "att,4976#def,2488#hp,19904#cri,1492#defcri,1492#dodge,1492#hit,1492#adddamagemonx,0.33#adddamagebossx,0.066",
	},
	['604']={
		['ID'] = 604,
		['star_attr'] = "att,5528#def,2764#hp,22112#cri,1658#defcri,1658#dodge,1658#hit,1658#adddamagemonx,0.34#adddamagebossx,0.068",
	},
	['700']={
		['ID'] = 700,
		['star_attr'] = "att,6080#def,3040#hp,24320#cri,1824#defcri,1824#dodge,1824#hit,1824#adddamagemonx,0.35#adddamagebossx,0.07",
	},
	['701']={
		['ID'] = 701,
		['star_attr'] = "att,6900#def,3450#hp,27600#cri,2070#defcri,2070#dodge,2070#hit,2070#adddamagemonx,0.36#adddamagebossx,0.072",
	},
	['702']={
		['ID'] = 702,
		['star_attr'] = "att,7720#def,3860#hp,30880#cri,2316#defcri,2316#dodge,2316#hit,2316#adddamagemonx,0.37#adddamagebossx,0.074",
	},
	['703']={
		['ID'] = 703,
		['star_attr'] = "att,8540#def,4270#hp,34160#cri,2562#defcri,2562#dodge,2562#hit,2562#adddamagemonx,0.38#adddamagebossx,0.076",
	},
	['704']={
		['ID'] = 704,
		['star_attr'] = "att,9360#def,4680#hp,37440#cri,2808#defcri,2808#dodge,2808#hit,2808#adddamagemonx,0.39#adddamagebossx,0.078",
	},
	['800']={
		['ID'] = 800,
		['star_attr'] = "att,10180#def,5090#hp,40720#cri,3054#defcri,3054#dodge,3054#hit,3054#adddamagemonx,0.4#adddamagebossx,0.08",
	},
	['801']={
		['ID'] = 801,
		['star_attr'] = "att,11104#def,5552#hp,44416#cri,3330#defcri,3330#dodge,3330#hit,3330#adddamagemonx,0.41#adddamagebossx,0.082",
	},
	['802']={
		['ID'] = 802,
		['star_attr'] = "att,12028#def,6014#hp,48112#cri,3608#defcri,3608#dodge,3608#hit,3608#adddamagemonx,0.42#adddamagebossx,0.084",
	},
	['803']={
		['ID'] = 803,
		['star_attr'] = "att,12952#def,6476#hp,51808#cri,3884#defcri,3884#dodge,3884#hit,3884#adddamagemonx,0.43#adddamagebossx,0.086",
	},
	['804']={
		['ID'] = 804,
		['star_attr'] = "att,13876#def,6938#hp,55504#cri,4162#defcri,4162#dodge,4162#hit,4162#adddamagemonx,0.44#adddamagebossx,0.088",
	},
	['900']={
		['ID'] = 900,
		['star_attr'] = "att,14800#def,7400#hp,59200#cri,4440#defcri,4440#dodge,4440#hit,4440#adddamagemonx,0.45#adddamagebossx,0.09",
	},
	['901']={
		['ID'] = 901,
		['star_attr'] = "att,15840#def,7920#hp,63360#cri,4752#defcri,4752#dodge,4752#hit,4752#adddamagemonx,0.46#adddamagebossx,0.092",
	},
	['902']={
		['ID'] = 902,
		['star_attr'] = "att,16880#def,8440#hp,67520#cri,5064#defcri,5064#dodge,5064#hit,5064#adddamagemonx,0.47#adddamagebossx,0.094",
	},
	['903']={
		['ID'] = 903,
		['star_attr'] = "att,17920#def,8960#hp,71680#cri,5376#defcri,5376#dodge,5376#hit,5376#adddamagemonx,0.48#adddamagebossx,0.096",
	},
	['904']={
		['ID'] = 904,
		['star_attr'] = "att,18960#def,9480#hp,75840#cri,5688#defcri,5688#dodge,5688#hit,5688#adddamagemonx,0.49#adddamagebossx,0.098",
	},
	['1000']={
		['ID'] = 1000,
		['star_attr'] = "att,20000#def,10000#hp,80000#cri,6000#defcri,6000#dodge,6000#hit,6000#adddamagemonx,0.5#adddamagebossx,0.1",
	},
};