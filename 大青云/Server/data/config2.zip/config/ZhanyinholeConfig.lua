ZhanyinholeConfig={
	['1']={
		['id'] = 1,
		['level'] = 10,
		['attrmuti'] = 1,
	},
	['2']={
		['id'] = 2,
		['level'] = 40,
		['attrmuti'] = 1,
	},
	['3']={
		['id'] = 3,
		['level'] = 100,
		['attrmuti'] = 1,
	},
	['4']={
		['id'] = 4,
		['level'] = 180,
		['attrmuti'] = 1.5,
	},
	['5']={
		['id'] = 5,
		['level'] = 220,
		['attrmuti'] = 1,
	},
	['6']={
		['id'] = 6,
		['level'] = 250,
		['attrmuti'] = 1,
	},
	['7']={
		['id'] = 7,
		['level'] = 280,
		['attrmuti'] = 1.5,
	},
	['8']={
		['id'] = 8,
		['level'] = 330,
		['attrmuti'] = 1,
	},
	['9']={
		['id'] = 9,
		['level'] = 370,
		['attrmuti'] = 1,
	},
	['10']={
		['id'] = 10,
		['level'] = 400,
		['attrmuti'] = 2,
	},
};