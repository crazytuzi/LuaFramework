BaseAttrConfig={
	['Hunli_To_Atk']={
		['str'] = "Hunli_To_Atk",
		['val'] = 1,
	},
	['TiPo_To_MaxHp']={
		['str'] = "TiPo_To_MaxHp",
		['val'] = 10,
	},
	['TiPo_To_Def']={
		['str'] = "TiPo_To_Def",
		['val'] = 0.5,
	},
	['ShengFa_To_Hit']={
		['str'] = "ShengFa_To_Hit",
		['val'] = 1,
	},
	['Shengfa_To_Dodge']={
		['str'] = "Shengfa_To_Dodge",
		['val'] = 1,
	},
	['JingShen_To_Cri']={
		['str'] = "JingShen_To_Cri",
		['val'] = 1,
	},
	['JingShen_To_DefCri']={
		['str'] = "JingShen_To_DefCri",
		['val'] = 1,
	},
};