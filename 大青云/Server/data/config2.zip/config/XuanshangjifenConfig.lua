XuanshangjifenConfig={
	['1']={
		['id'] = 1,
		['needStore'] = 20,
		['itemReward'] = "110510005,1#140621038,5",
	},
	['2']={
		['id'] = 2,
		['needStore'] = 50,
		['itemReward'] = "110622003,2#140621037,2",
	},
	['3']={
		['id'] = 3,
		['needStore'] = 80,
		['itemReward'] = "110220004,1#110220033,1",
	},
	['4']={
		['id'] = 4,
		['needStore'] = 100,
		['itemReward'] = "110220012,1#140620006,5",
	},
	['5']={
		['id'] = 5,
		['needStore'] = 120,
		['itemReward'] = "110600100,5#140621200,5",
	},
	['6']={
		['id'] = 6,
		['needStore'] = 150,
		['itemReward'] = "110622004,1#140621058,1",
	},
};