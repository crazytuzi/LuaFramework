RefinlinkConfig={
	['1']={
		['id'] = 1,
		['openlvl'] = 50,
		['addAtb'] = "att,80#def,40#hp,320",
	},
	['2']={
		['id'] = 2,
		['openlvl'] = 100,
		['addAtb'] = "att,150#def,75#hp,600",
	},
	['3']={
		['id'] = 3,
		['openlvl'] = 150,
		['addAtb'] = "att,320#def,160#hp,1280",
	},
	['4']={
		['id'] = 4,
		['openlvl'] = 200,
		['addAtb'] = "att,640#def,320#hp,2560",
	},
	['5']={
		['id'] = 5,
		['openlvl'] = 250,
		['addAtb'] = "att,1200#def,600#hp,4800",
	},
	['6']={
		['id'] = 6,
		['openlvl'] = 300,
		['addAtb'] = "att,2000#def,1000#hp,8000",
	},
};