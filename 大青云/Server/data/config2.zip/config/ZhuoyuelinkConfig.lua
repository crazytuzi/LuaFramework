ZhuoyuelinkConfig={
	['1']={
		['id'] = 1,
		['num'] = 7,
		['attr'] = "att,40#def,20#hp,160#super,0.005",
	},
	['2']={
		['id'] = 2,
		['num'] = 11,
		['attr'] = "att,80#def,40#hp,320#super,0.007",
	},
	['3']={
		['id'] = 3,
		['num'] = 17,
		['attr'] = "att,120#def,60#hp,480#super,0.009",
	},
	['4']={
		['id'] = 4,
		['num'] = 22,
		['attr'] = "att,200#def,100#hp,800#super,0.011",
	},
	['5']={
		['id'] = 5,
		['num'] = 28,
		['attr'] = "att,320#def,160#hp,1280#super,0.013",
	},
	['6']={
		['id'] = 6,
		['num'] = 33,
		['attr'] = "att,500#def,250#hp,2000#super,0.015",
	},
};