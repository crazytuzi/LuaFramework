HomequestitemrewardConfig={
	['140621059']={
		['id'] = 140621059,
		['range'] = 10000,
		['needRenwudian'] = 1,
	},
	['110622016']={
		['id'] = 110622016,
		['range'] = 5000,
		['needRenwudian'] = 1,
	},
};