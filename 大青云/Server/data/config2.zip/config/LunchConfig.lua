LunchConfig={
	['1']={
		['id'] = 1,
		['cost_type'] = 3,
		['cost'] = "",
	},
	['2']={
		['id'] = 2,
		['cost_type'] = 1,
		['cost'] = "10,50000",
	},
	['3']={
		['id'] = 3,
		['cost_type'] = 1,
		['cost'] = "12,10",
	},
};