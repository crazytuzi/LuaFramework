SpecialtuangouConfig={
	['1']={
		['id'] = 1,
		['name'] = "shouchongtuangou1",
		['interal'] = 3,
		['max_count'] = 50,
		['per'] = 1,
		['add_min'] = 2,
		['add_max'] = 4,
	},
	['2']={
		['id'] = 2,
		['name'] = "shouchongtuangou2",
		['interal'] = 4,
		['max_count'] = 80,
		['per'] = 1,
		['add_min'] = 2,
		['add_max'] = 4,
	},
	['3']={
		['id'] = 3,
		['name'] = "shouchongtuangou3",
		['interal'] = 5,
		['max_count'] = 120,
		['per'] = 1,
		['add_min'] = 2,
		['add_max'] = 4,
	},
};