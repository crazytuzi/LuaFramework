AchievementConfig={
	['800001']={
		['id'] = 800001,
		['group'] = 8,
		['level'] = 1,
		['next'] = 0,
		['kind'] = 150,
		['type'] = 0,
		['val_type'] = 1,
		['val'] = 1,
		['exp'] = 0,
		['reward'] = "",
		['point'] = 5,
	},
};