MarrytimeConfig={
	['1']={
		['id'] = 1,
		['openTime'] = 1000,
		['closeTime'] = 1100,
		['openCruiseTime'] = 1000,
		['closeCruiseTime'] = 1030,
	},
	['2']={
		['id'] = 2,
		['openTime'] = 1200,
		['closeTime'] = 1300,
		['openCruiseTime'] = 1200,
		['closeCruiseTime'] = 1230,
	},
	['3']={
		['id'] = 3,
		['openTime'] = 1400,
		['closeTime'] = 1500,
		['openCruiseTime'] = 1400,
		['closeCruiseTime'] = 1430,
	},
	['4']={
		['id'] = 4,
		['openTime'] = 1600,
		['closeTime'] = 1700,
		['openCruiseTime'] = 1600,
		['closeCruiseTime'] = 1630,
	},
	['5']={
		['id'] = 5,
		['openTime'] = 1800,
		['closeTime'] = 1900,
		['openCruiseTime'] = 1800,
		['closeCruiseTime'] = 1830,
	},
	['6']={
		['id'] = 6,
		['openTime'] = 2100,
		['closeTime'] = 2200,
		['openCruiseTime'] = 2100,
		['closeCruiseTime'] = 2130,
	},
};