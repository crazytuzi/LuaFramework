XianyuancaveConfig={
	['1']={
		['id'] = 1,
		['bossID'] = 10901001,
		['activityID'] = 10008,
		['joinreward'] = "170002001,1",
	},
	['2']={
		['id'] = 2,
		['bossID'] = 10901002,
		['activityID'] = 10008,
		['joinreward'] = "170002001,1",
	},
	['3']={
		['id'] = 3,
		['bossID'] = 10901003,
		['activityID'] = 10008,
		['joinreward'] = "170002001,1",
	},
	['4']={
		['id'] = 4,
		['bossID'] = 10901004,
		['activityID'] = 10008,
		['joinreward'] = "170002001,1",
	},
	['5']={
		['id'] = 5,
		['bossID'] = 10901005,
		['activityID'] = 10008,
		['joinreward'] = "170002001,1",
	},
	['6']={
		['id'] = 6,
		['bossID'] = 10621201,
		['activityID'] = 0,
		['joinreward'] = "",
	},
	['7']={
		['id'] = 7,
		['bossID'] = 10622201,
		['activityID'] = 0,
		['joinreward'] = "",
	},
	['8']={
		['id'] = 8,
		['bossID'] = 10623201,
		['activityID'] = 0,
		['joinreward'] = "",
	},
	['9']={
		['id'] = 9,
		['bossID'] = 10624201,
		['activityID'] = 0,
		['joinreward'] = "",
	},
	['10']={
		['id'] = 10,
		['bossID'] = 10625201,
		['activityID'] = 0,
		['joinreward'] = "",
	},
};