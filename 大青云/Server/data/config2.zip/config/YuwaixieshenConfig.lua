YuwaixieshenConfig={
	['1']={
		['id'] = 1,
		['time'] = 3,
		['monsterID'] = 10710001,
	},
	['2']={
		['id'] = 2,
		['time'] = 3,
		['monsterID'] = 10710002,
	},
	['3']={
		['id'] = 3,
		['time'] = 3,
		['monsterID'] = 10710003,
	},
	['4']={
		['id'] = 4,
		['time'] = 3,
		['monsterID'] = 10710004,
	},
	['5']={
		['id'] = 5,
		['time'] = 3,
		['monsterID'] = 10710005,
	},
	['6']={
		['id'] = 6,
		['time'] = 3,
		['monsterID'] = 10710006,
	},
	['7']={
		['id'] = 7,
		['time'] = 3,
		['monsterID'] = 10710007,
	},
	['8']={
		['id'] = 8,
		['time'] = 3,
		['monsterID'] = 10710008,
	},
	['9']={
		['id'] = 9,
		['time'] = 3,
		['monsterID'] = 10710009,
	},
	['10']={
		['id'] = 10,
		['time'] = 3,
		['monsterID'] = 10710010,
	},
};