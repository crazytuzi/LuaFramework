HomequestlvConfig={
	['1']={
		['id'] = 1,
		['levelDiff'] = -5,
		['levelRange'] = 10,
	},
	['2']={
		['id'] = 2,
		['levelDiff'] = -4,
		['levelRange'] = 20,
	},
	['3']={
		['id'] = 3,
		['levelDiff'] = -3,
		['levelRange'] = 40,
	},
	['4']={
		['id'] = 4,
		['levelDiff'] = -2,
		['levelRange'] = 60,
	},
	['5']={
		['id'] = 5,
		['levelDiff'] = -1,
		['levelRange'] = 80,
	},
	['6']={
		['id'] = 6,
		['levelDiff'] = 0,
		['levelRange'] = 100,
	},
	['7']={
		['id'] = 7,
		['levelDiff'] = 1,
		['levelRange'] = 80,
	},
	['8']={
		['id'] = 8,
		['levelDiff'] = 2,
		['levelRange'] = 60,
	},
	['9']={
		['id'] = 9,
		['levelDiff'] = 3,
		['levelRange'] = 40,
	},
	['10']={
		['id'] = 10,
		['levelDiff'] = 4,
		['levelRange'] = 20,
	},
	['11']={
		['id'] = 11,
		['levelDiff'] = 5,
		['levelRange'] = 10,
	},
};