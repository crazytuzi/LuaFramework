XiuweipointConfig={
	['1']={
		['ID'] = 1,
		['monster_type'] = 1,
		['xiuwei'] = 8,
	},
	['2']={
		['ID'] = 2,
		['monster_type'] = 2,
		['xiuwei'] = 20,
	},
	['3']={
		['ID'] = 3,
		['monster_type'] = 3,
		['xiuwei'] = 100,
	},
	['4']={
		['ID'] = 4,
		['monster_type'] = 4,
		['xiuwei'] = 1000,
	},
	['5']={
		['ID'] = 5,
		['monster_type'] = 5,
		['xiuwei'] = 10,
	},
	['6']={
		['ID'] = 6,
		['monster_type'] = 6,
		['xiuwei'] = 100,
	},
	['7']={
		['ID'] = 7,
		['monster_type'] = 7,
		['xiuwei'] = 100,
	},
	['8']={
		['ID'] = 8,
		['monster_type'] = 8,
		['xiuwei'] = 10,
	},
	['9']={
		['ID'] = 9,
		['monster_type'] = 9,
		['xiuwei'] = 10,
	},
	['10']={
		['ID'] = 10,
		['monster_type'] = 10,
		['xiuwei'] = 1000,
	},
	['11']={
		['ID'] = 11,
		['monster_type'] = 11,
		['xiuwei'] = 500,
	},
	['12']={
		['ID'] = 12,
		['monster_type'] = 12,
		['xiuwei'] = 1000,
	},
	['13']={
		['ID'] = 13,
		['monster_type'] = 13,
		['xiuwei'] = 10,
	},
	['14']={
		['ID'] = 14,
		['monster_type'] = 14,
		['xiuwei'] = 10,
	},
	['15']={
		['ID'] = 15,
		['monster_type'] = 15,
		['xiuwei'] = 500,
	},
	['16']={
		['ID'] = 16,
		['monster_type'] = 16,
		['xiuwei'] = 1000,
	},
	['17']={
		['ID'] = 17,
		['monster_type'] = 17,
		['xiuwei'] = 250,
	},
	['18']={
		['ID'] = 18,
		['monster_type'] = 18,
		['xiuwei'] = 20,
	},
	['19']={
		['ID'] = 19,
		['monster_type'] = 19,
		['xiuwei'] = 50,
	},
};