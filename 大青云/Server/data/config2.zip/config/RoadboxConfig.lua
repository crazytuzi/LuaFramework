RoadboxConfig={
	['1']={
		['id'] = 1,
		['level'] = 50,
		['openStar'] = 30,
		['boxReward'] = "110600001,100#110610001,100",
		['mapId'] = 11403004,
	},
};