JjcEventConfig={
	['1']={
		['id'] = 1,
		['chal'] = 0,
		['win'] = 0,
		['rank_change'] = 0,
	},
	['2']={
		['id'] = 2,
		['chal'] = 0,
		['win'] = 1,
		['rank_change'] = 0,
	},
	['3']={
		['id'] = 3,
		['chal'] = 0,
		['win'] = 1,
		['rank_change'] = 1,
	},
	['4']={
		['id'] = 4,
		['chal'] = 1,
		['win'] = 0,
		['rank_change'] = 0,
	},
	['5']={
		['id'] = 5,
		['chal'] = 1,
		['win'] = 0,
		['rank_change'] = 2,
	},
	['6']={
		['id'] = 6,
		['chal'] = 1,
		['win'] = 1,
		['rank_change'] = 0,
	},
};