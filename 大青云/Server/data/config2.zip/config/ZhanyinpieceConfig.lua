ZhanyinpieceConfig={
	['1']={
		['id'] = 1,
		['num'] = 1,
		['goldweight'] = 10,
		['moneyweight'] = 0,
	},
	['2']={
		['id'] = 2,
		['num'] = 2,
		['goldweight'] = 5,
		['moneyweight'] = 0,
	},
	['3']={
		['id'] = 3,
		['num'] = 3,
		['goldweight'] = 2,
		['moneyweight'] = 0,
	},
	['4']={
		['id'] = 4,
		['num'] = 4,
		['goldweight'] = 1,
		['moneyweight'] = 0,
	},
	['5']={
		['id'] = 5,
		['num'] = 5,
		['goldweight'] = 0,
		['moneyweight'] = 15,
	},
	['6']={
		['id'] = 6,
		['num'] = 10,
		['goldweight'] = 0,
		['moneyweight'] = 8,
	},
	['7']={
		['id'] = 7,
		['num'] = 15,
		['goldweight'] = 0,
		['moneyweight'] = 3,
	},
	['8']={
		['id'] = 8,
		['num'] = 20,
		['goldweight'] = 0,
		['moneyweight'] = 2,
	},
};