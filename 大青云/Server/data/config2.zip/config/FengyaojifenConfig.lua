FengyaojifenConfig={
	['1']={
		['id'] = 1,
		['needStore'] = 50,
		['itemReward'] = "13,50",
	},
	['2']={
		['id'] = 2,
		['needStore'] = 100,
		['itemReward'] = "180500003,1",
	},
	['3']={
		['id'] = 3,
		['needStore'] = 150,
		['itemReward'] = "180500201,10",
	},
	['4']={
		['id'] = 4,
		['needStore'] = 200,
		['itemReward'] = "180500401,4",
	},
	['5']={
		['id'] = 5,
		['needStore'] = 250,
		['itemReward'] = "180500301,1",
	},
	['6']={
		['id'] = 6,
		['needStore'] = 300,
		['itemReward'] = "150030202,1",
	},
};