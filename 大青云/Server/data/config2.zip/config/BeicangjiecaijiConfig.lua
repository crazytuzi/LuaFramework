BeicangjiecaijiConfig={
	['40006']={
		['collection'] = 40006,
		['score'] = 100,
	},
	['40007']={
		['collection'] = 40007,
		['score'] = 50,
	},
};