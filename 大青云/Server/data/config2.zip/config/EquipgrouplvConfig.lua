EquipgrouplvConfig={
	['1']={
		['level'] = 1,
		['attrPlus'] = 10,
	},
	['2']={
		['level'] = 2,
		['attrPlus'] = 20,
	},
	['3']={
		['level'] = 3,
		['attrPlus'] = 30,
	},
	['4']={
		['level'] = 4,
		['attrPlus'] = 40,
	},
	['5']={
		['level'] = 5,
		['attrPlus'] = 50,
	},
	['6']={
		['level'] = 6,
		['attrPlus'] = 60,
	},
	['7']={
		['level'] = 7,
		['attrPlus'] = 70,
	},
	['8']={
		['level'] = 8,
		['attrPlus'] = 80,
	},
	['9']={
		['level'] = 9,
		['attrPlus'] = 90,
	},
	['10']={
		['level'] = 10,
		['attrPlus'] = 100,
	},
};