PropAttConfig={
	['qianghua']={
		['type'] = "qianghua",
		['descrip'] = "强化等级",
	},
	['bind']={
		['type'] = "bind",
		['descrip'] = "绑定状态",
	},
};