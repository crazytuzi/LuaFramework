ConsumeConfig={
	['1']={
		['type'] = 1,
		['descrip'] = "(消耗)武魂",
		['isaddicted'] = 0,
	},
	['2']={
		['type'] = 2,
		['descrip'] = "(消耗)技能学习",
		['isaddicted'] = 0,
	},
	['3']={
		['type'] = 3,
		['descrip'] = "(消耗)发送喇叭",
		['isaddicted'] = 0,
	},
	['4']={
		['type'] = 4,
		['descrip'] = "(消耗)背包扩充",
		['isaddicted'] = 0,
	},
	['5']={
		['type'] = 5,
		['descrip'] = "(消耗)原地复活",
		['isaddicted'] = 0,
	},
	['6']={
		['type'] = 6,
		['descrip'] = "(消耗)坐骑",
		['isaddicted'] = 0,
	},
	['7']={
		['type'] = 7,
		['descrip'] = "(消耗)创建帮派",
		['isaddicted'] = 0,
	},
	['8']={
		['type'] = 8,
		['descrip'] = "(消耗)商店",
		['isaddicted'] = 0,
	},
	['9']={
		['type'] = 9,
		['descrip'] = "(消耗)回购",
		['isaddicted'] = 0,
	},
	['10']={
		['type'] = 10,
		['descrip'] = "(消耗)自动购买",
		['isaddicted'] = 0,
	},
	['11']={
		['type'] = 11,
		['descrip'] = "(消耗)强化",
		['isaddicted'] = 0,
	},
	['12']={
		['type'] = 12,
		['descrip'] = "(消耗)传承",
		['isaddicted'] = 0,
	},
	['13']={
		['type'] = 13,
		['descrip'] = "(消耗)捐献",
		['isaddicted'] = 0,
	},
	['14']={
		['type'] = 14,
		['descrip'] = "(消耗)任务",
		['isaddicted'] = 0,
	},
	['15']={
		['type'] = 15,
		['descrip'] = "(消耗)封妖",
		['isaddicted'] = 0,
	},
	['16']={
		['type'] = 16,
		['descrip'] = "(消耗)补签",
		['isaddicted'] = 0,
	},
	['17']={
		['type'] = 17,
		['descrip'] = "(消耗)大地图传送",
		['isaddicted'] = 0,
	},
	['18']={
		['type'] = 18,
		['descrip'] = "(消耗)竞技场消耗",
		['isaddicted'] = 0,
	},
	['19']={
		['type'] = 19,
		['descrip'] = "(消耗)采蘑菇快速解救消耗",
		['isaddicted'] = 0,
	},
	['20']={
		['type'] = 20,
		['descrip'] = "(消耗)神兵",
		['isaddicted'] = 0,
	},
	['21']={
		['type'] = 21,
		['descrip'] = "(消耗)卓越孔升级",
		['isaddicted'] = 0,
	},
	['22']={
		['type'] = 22,
		['descrip'] = "(消耗)安装卓越属性消耗",
		['isaddicted'] = 0,
	},
	['23']={
		['type'] = 23,
		['descrip'] = "(消耗)卸载卓越属性消耗",
		['isaddicted'] = 0,
	},
	['24']={
		['type'] = 24,
		['descrip'] = "(消耗)境界突破消耗",
		['isaddicted'] = 0,
	},
	['25']={
		['type'] = 25,
		['descrip'] = "(消耗)宝石升级",
		['isaddicted'] = 0,
	},
	['26']={
		['type'] = 26,
		['descrip'] = "(消耗)每日必做",
		['isaddicted'] = 0,
	},
	['27']={
		['type'] = 27,
		['descrip'] = "(消耗)副本",
		['isaddicted'] = 0,
	},
	['28']={
		['type'] = 28,
		['descrip'] = "(消耗)升阶",
		['isaddicted'] = 0,
	},
	['29']={
		['type'] = 29,
		['descrip'] = "(消耗)定时副本",
		['isaddicted'] = 0,
	},
	['30']={
		['type'] = 30,
		['descrip'] = "(消耗)珍宝阁",
		['isaddicted'] = 0,
	},
	['31']={
		['type'] = 31,
		['descrip'] = "(消耗)直接使用物品",
		['isaddicted'] = 0,
	},
	['32']={
		['type'] = 32,
		['descrip'] = "(消耗)出售物品",
		['isaddicted'] = 0,
	},
	['33']={
		['type'] = 33,
		['descrip'] = "(消耗)丢弃",
		['isaddicted'] = 0,
	},
	['34']={
		['type'] = 34,
		['descrip'] = "(消耗)交易",
		['isaddicted'] = 0,
	},
	['35']={
		['type'] = 35,
		['descrip'] = "(消耗)合成",
		['isaddicted'] = 0,
	},
	['36']={
		['type'] = 36,
		['descrip'] = "(消耗)分解",
		['isaddicted'] = 0,
	},
	['37']={
		['type'] = 37,
		['descrip'] = "境界",
		['isaddicted'] = 0,
	},
	['38']={
		['type'] = 38,
		['descrip'] = "存帮派仓库",
		['isaddicted'] = 0,
	},
	['39']={
		['type'] = 39,
		['descrip'] = "战印",
		['isaddicted'] = 0,
	},
	['40']={
		['type'] = 40,
		['descrip'] = "任务多倍领取",
		['isaddicted'] = 0,
	},
	['41']={
		['type'] = 41,
		['descrip'] = "追加传承",
		['isaddicted'] = 0,
	},
	['42']={
		['type'] = 42,
		['descrip'] = "宝甲",
		['isaddicted'] = 0,
	},
	['43']={
		['type'] = 43,
		['descrip'] = "徽章",
		['isaddicted'] = 0,
	},
	['44']={
		['type'] = 44,
		['descrip'] = "帮派祈福",
		['isaddicted'] = 0,
	},
	['45']={
		['type'] = 45,
		['descrip'] = "炼体",
		['isaddicted'] = 0,
	},
	['46']={
		['type'] = 46,
		['descrip'] = "装备打造",
		['isaddicted'] = 0,
	},
	['47']={
		['type'] = 47,
		['descrip'] = "主宰之路",
		['isaddicted'] = 0,
	},
	['48']={
		['type'] = 48,
		['descrip'] = "境界突破",
		['isaddicted'] = 0,
	},
	['49']={
		['type'] = 49,
		['descrip'] = "炼化消耗",
		['isaddicted'] = 0,
	},
	['50']={
		['type'] = 50,
		['descrip'] = "礼金卡消耗",
		['isaddicted'] = 0,
	},
	['51']={
		['type'] = 51,
		['descrip'] = "日环升星",
		['isaddicted'] = 0,
	},
	['52']={
		['type'] = 52,
		['descrip'] = "一键完成",
		['isaddicted'] = 0,
	},
	['53']={
		['type'] = 53,
		['descrip'] = "灵阵",
		['isaddicted'] = 0,
	},
	['54']={
		['type'] = 54,
		['descrip'] = "萌宠",
		['isaddicted'] = 0,
	},
	['55']={
		['type'] = 55,
		['descrip'] = "每日祈福购买",
		['isaddicted'] = 0,
	},
	['56']={
		['type'] = 56,
		['descrip'] = "寄售行购买",
		['isaddicted'] = 0,
	},
	['57']={
		['type'] = 57,
		['descrip'] = "翅膀合成",
		['isaddicted'] = 0,
	},
	['58']={
		['type'] = 58,
		['descrip'] = "激活vip",
		['isaddicted'] = 0,
	},
	['59']={
		['type'] = 59,
		['descrip'] = "寻宝",
		['isaddicted'] = 0,
	},
	['60']={
		['type'] = 60,
		['descrip'] = "流水副本多倍领取",
		['isaddicted'] = 0,
	},
	['61']={
		['type'] = 61,
		['descrip'] = "家园",
		['isaddicted'] = 0,
	},
	['62']={
		['type'] = 62,
		['descrip'] = "跨服1V1",
		['isaddicted'] = 0,
	},
	['63']={
		['type'] = 63,
		['descrip'] = "熔炼炉",
		['isaddicted'] = 0,
	},
	['64']={
		['type'] = 64,
		['descrip'] = "转生",
		['isaddicted'] = 0,
	},
	['65']={
		['type'] = 65,
		['descrip'] = "续费翅膀",
		['isaddicted'] = 0,
	},
	['66']={
		['type'] = 66,
		['descrip'] = "翅膀到期",
		['isaddicted'] = 0,
	},
	['67']={
		['type'] = 67,
		['descrip'] = "兑换消耗",
		['isaddicted'] = 0,
	},
	['68']={
		['type'] = 68,
		['descrip'] = "灵兽坐骑",
		['isaddicted'] = 0,
	},
	['69']={
		['type'] = 69,
		['descrip'] = "离线",
		['isaddicted'] = 0,
	},
	['70']={
		['type'] = 70,
		['descrip'] = "团购",
		['isaddicted'] = 0,
	},
	['71']={
		['type'] = 71,
		['descrip'] = "经验副本",
		['isaddicted'] = 0,
	},
	['72']={
		['type'] = 72,
		['descrip'] = "铭刻消耗",
		['isaddicted'] = 0,
	},
	['73']={
		['type'] = 73,
		['descrip'] = "个人boss消耗",
		['isaddicted'] = 0,
	},
	['74']={
		['type'] = 74,
		['descrip'] = "新套装",
		['isaddicted'] = 0,
	},
	['75']={
		['type'] = 75,
		['descrip'] = "道具兑换商店",
		['isaddicted'] = 0,
	},
	['76']={
		['type'] = 76,
		['descrip'] = "骑战",
		['isaddicted'] = 0,
	},
	['77']={
		['type'] = 77,
		['descrip'] = "弹劾",
		['isaddicted'] = 0,
	},
	['78']={
		['type'] = 78,
		['descrip'] = "屠魔",
		['isaddicted'] = 0,
	},
	['79']={
		['type'] = 79,
		['descrip'] = "卓越洗练",
		['isaddicted'] = 0,
	},
	['80']={
		['type'] = 80,
		['descrip'] = "套装升级",
		['isaddicted'] = 0,
	},
	['81']={
		['type'] = 81,
		['descrip'] = "噬魂徽章",
		['isaddicted'] = 0,
	},
	['82']={
		['type'] = 82,
		['descrip'] = "卓越洗练属性",
		['isaddicted'] = 0,
	},
	['83']={
		['type'] = 83,
		['descrip'] = "翅膀强化",
		['isaddicted'] = 0,
	},
	['84']={
		['type'] = 84,
		['descrip'] = "圣灵",
		['isaddicted'] = 0,
	},
	['85']={
		['type'] = 85,
		['descrip'] = "圣诞捐献",
		['isaddicted'] = 0,
	},
	['86']={
		['type'] = 86,
		['descrip'] = "跨服擂台下注",
		['isaddicted'] = 0,
	},
	['87']={
		['type'] = 87,
		['descrip'] = "跨服擂台鼓舞",
		['isaddicted'] = 0,
	},
	['88']={
		['type'] = 88,
		['descrip'] = "结婚",
		['isaddicted'] = 0,
	},
	['89']={
		['type'] = 89,
		['descrip'] = "神武",
		['isaddicted'] = 0,
	},
	['90']={
		['type'] = 90,
		['descrip'] = "元灵",
		['isaddicted'] = 0,
	},
	['91']={
		['type'] = 91,
		['descrip'] = "境界巩固",
		['isaddicted'] = 0,
	},
	['92']={
		['type'] = 92,
		['descrip'] = "圣魂",
		['isaddicted'] = 0,
	},
	['93']={
		['type'] = 93,
		['descrip'] = "改名",
		['isaddicted'] = 0,
	},
	['94']={
		['type'] = 94,
		['descrip'] = "轮盘",
		['isaddicted'] = 0,
	},
	['95']={
		['type'] = 95,
		['descrip'] = "装备位套装",
		['isaddicted'] = 0,
	},
	['96']={
		['type'] = 96,
		['descrip'] = "五行",
		['isaddicted'] = 0,
	},
	['97']={
		['type'] = 97,
		['descrip'] = "自己交易栏操作(消耗)",
		['isaddicted'] = 0,
	},
	['98']={
		['type'] = 98,
		['descrip'] = "婚戒强化",
		['isaddicted'] = 0,
	},
	['99']={
		['type'] = 99,
		['descrip'] = "兽魂",
		['isaddicted'] = 0,
	},
	['100']={
		['type'] = 100,
		['descrip'] = "战弩",
		['isaddicted'] = 0,
	},
	['101']={
		['type'] = 101,
		['descrip'] = "(获得)自己交易栏操作",
		['isaddicted'] = 1,
	},
	['102']={
		['type'] = 102,
		['descrip'] = "(获得)交易完成获得",
		['isaddicted'] = 1,
	},
	['103']={
		['type'] = 103,
		['descrip'] = "(获得)任务奖励",
		['isaddicted'] = 0,
	},
	['104']={
		['type'] = 104,
		['descrip'] = "(获得)掉落",
		['isaddicted'] = 0,
	},
	['105']={
		['type'] = 105,
		['descrip'] = "(获得)邮件获取",
		['isaddicted'] = 0,
	},
	['106']={
		['type'] = 106,
		['descrip'] = "(获得)出售物品",
		['isaddicted'] = 1,
	},
	['107']={
		['type'] = 107,
		['descrip'] = "(获得)副本奖励",
		['isaddicted'] = 0,
	},
	['108']={
		['type'] = 108,
		['descrip'] = "(获得)GM指令获得",
		['isaddicted'] = 1,
	},
	['109']={
		['type'] = 109,
		['descrip'] = "(获得)竞技场",
		['isaddicted'] = 0,
	},
	['110']={
		['type'] = 110,
		['descrip'] = "(获得)活动",
		['isaddicted'] = 0,
	},
	['111']={
		['type'] = 111,
		['descrip'] = "(获得)帮派地宫活动",
		['isaddicted'] = 0,
	},
	['112']={
		['type'] = 112,
		['descrip'] = "(获得)物品",
		['isaddicted'] = 0,
	},
	['113']={
		['type'] = 113,
		['descrip'] = "(获得)打坐",
		['isaddicted'] = 0,
	},
	['114']={
		['type'] = 114,
		['descrip'] = "(获得)帮派战",
		['isaddicted'] = 0,
	},
	['115']={
		['type'] = 115,
		['descrip'] = "(获得)激活码",
		['isaddicted'] = 1,
	},
	['116']={
		['type'] = 116,
		['descrip'] = "(获得)平台充值",
		['isaddicted'] = 1,
	},
	['117']={
		['type'] = 117,
		['descrip'] = "(获得)王城战",
		['isaddicted'] = 0,
	},
	['118']={
		['type'] = 118,
		['descrip'] = "(获得)膜拜城主",
		['isaddicted'] = 0,
	},
	['119']={
		['type'] = 119,
		['descrip'] = "(获得)通天塔",
		['isaddicted'] = 1,
	},
	['120']={
		['type'] = 120,
		['descrip'] = "(获得)礼包",
		['isaddicted'] = 0,
	},
	['121']={
		['type'] = 121,
		['descrip'] = "(获得)合成",
		['isaddicted'] = 1,
	},
	['122']={
		['type'] = 122,
		['descrip'] = "(获得)分解",
		['isaddicted'] = 1,
	},
	['123']={
		['type'] = 123,
		['descrip'] = "(获得)阵营战",
		['isaddicted'] = 0,
	},
	['124']={
		['type'] = 124,
		['descrip'] = "(获得)在线奖励",
		['isaddicted'] = 0,
	},
	['125']={
		['type'] = 125,
		['descrip'] = "(获得)任务道具",
		['isaddicted'] = 0,
	},
	['126']={
		['type'] = 126,
		['descrip'] = "(获得)日环",
		['isaddicted'] = 0,
	},
	['127']={
		['type'] = 127,
		['descrip'] = "(获得)封妖",
		['isaddicted'] = 0,
	},
	['128']={
		['type'] = 128,
		['descrip'] = "(获得)商店购买",
		['isaddicted'] = 1,
	},
	['129']={
		['type'] = 129,
		['descrip'] = "(获得)回购",
		['isaddicted'] = 1,
	},
	['130']={
		['type'] = 130,
		['descrip'] = "(获得)离线奖励",
		['isaddicted'] = 0,
	},
	['131']={
		['type'] = 131,
		['descrip'] = "(获得)副本随机事件",
		['isaddicted'] = 0,
	},
	['132']={
		['type'] = 132,
		['descrip'] = "(获得)等级奖励",
		['isaddicted'] = 0,
	},
	['133']={
		['type'] = 133,
		['descrip'] = "(获得)签到",
		['isaddicted'] = 0,
	},
	['134']={
		['type'] = 134,
		['descrip'] = "(获得)每日必做",
		['isaddicted'] = 0,
	},
	['135']={
		['type'] = 135,
		['descrip'] = "(获得)运营内置活动",
		['isaddicted'] = 1,
	},
	['136']={
		['type'] = 136,
		['descrip'] = "境界经验",
		['isaddicted'] = 0,
	},
	['137']={
		['type'] = 137,
		['descrip'] = "帮派仓库取",
		['isaddicted'] = 0,
	},
	['138']={
		['type'] = 138,
		['descrip'] = "极限副本",
		['isaddicted'] = 0,
	},
	['139']={
		['type'] = 139,
		['descrip'] = "V计划礼包",
		['isaddicted'] = 0,
	},
	['140']={
		['type'] = 140,
		['descrip'] = "微端奖励",
		['isaddicted'] = 0,
	},
	['141']={
		['type'] = 141,
		['descrip'] = "徽章;",
		['isaddicted'] = 0,
	},
	['142']={
		['type'] = 142,
		['descrip'] = "成就",
		['isaddicted'] = 0,
	},
	['143']={
		['type'] = 143,
		['descrip'] = "杀怪经验",
		['isaddicted'] = 0,
	},
	['144']={
		['type'] = 144,
		['descrip'] = "连斩经验",
		['isaddicted'] = 0,
	},
	['145']={
		['type'] = 145,
		['descrip'] = "开启背包格子",
		['isaddicted'] = 0,
	},
	['146']={
		['type'] = 146,
		['descrip'] = "组队共享",
		['isaddicted'] = 0,
	},
	['147']={
		['type'] = 147,
		['descrip'] = "卓越卷轴",
		['isaddicted'] = 0,
	},
	['148']={
		['type'] = 148,
		['descrip'] = "主宰之路",
		['isaddicted'] = 0,
	},
	['149']={
		['type'] = 149,
		['descrip'] = "装备打造",
		['isaddicted'] = 0,
	},
	['150']={
		['type'] = 150,
		['descrip'] = "好友奖励",
		['isaddicted'] = 0,
	},
	['151']={
		['type'] = 151,
		['descrip'] = "灵兽墓地",
		['isaddicted'] = 0,
	},
	['152']={
		['type'] = 152,
		['descrip'] = "每日祈福购买",
		['isaddicted'] = 0,
	},
	['153']={
		['type'] = 153,
		['descrip'] = "灵路试炼奖励",
		['isaddicted'] = 0,
	},
	['154']={
		['type'] = 154,
		['descrip'] = "活跃度",
		['isaddicted'] = 0,
	},
	['155']={
		['type'] = 155,
		['descrip'] = "灵光封魔",
		['isaddicted'] = 0,
	},
	['156']={
		['type'] = 156,
		['descrip'] = "寄售行购买",
		['isaddicted'] = 0,
	},
	['157']={
		['type'] = 157,
		['descrip'] = "寄售行购买下架",
		['isaddicted'] = 0,
	},
	['158']={
		['type'] = 158,
		['descrip'] = "翅膀合成",
		['isaddicted'] = 0,
	},
	['159']={
		['type'] = 159,
		['descrip'] = "激活vip",
		['isaddicted'] = 0,
	},
	['160']={
		['type'] = 160,
		['descrip'] = "vip周奖励",
		['isaddicted'] = 0,
	},
	['161']={
		['type'] = 161,
		['descrip'] = "vip等级奖励",
		['isaddicted'] = 0,
	},
	['162']={
		['type'] = 162,
		['descrip'] = "寻宝",
		['isaddicted'] = 0,
	},
	['163']={
		['type'] = 163,
		['descrip'] = "奇遇奖励",
		['isaddicted'] = 0,
	},
	['164']={
		['type'] = 164,
		['descrip'] = "卓越引导",
		['isaddicted'] = 0,
	},
	['165']={
		['type'] = 165,
		['descrip'] = "北仓界",
		['isaddicted'] = 0,
	},
	['166']={
		['type'] = 166,
		['descrip'] = "七日登录",
		['isaddicted'] = 0,
	},
	['167']={
		['type'] = 167,
		['descrip'] = "守护活动;",
		['isaddicted'] = 0,
	},
	['168']={
		['type'] = 168,
		['descrip'] = "VIP返还;",
		['isaddicted'] = 0,
	},
	['169']={
		['type'] = 169,
		['descrip'] = "家园;",
		['isaddicted'] = 0,
	},
	['170']={
		['type'] = 170,
		['descrip'] = "寄售;",
		['isaddicted'] = 0,
	},
	['171']={
		['type'] = 171,
		['descrip'] = "跨服1V1;",
		['isaddicted'] = 0,
	},
	['172']={
		['type'] = 172,
		['descrip'] = "跨服1V1排行奖励;",
		['isaddicted'] = 0,
	},
	['173']={
		['type'] = 173,
		['descrip'] = "360加速球;",
		['isaddicted'] = 0,
	},
	['174']={
		['type'] = 174,
		['descrip'] = "360游戏大厅",
		['isaddicted'] = 0,
	},
	['175']={
		['type'] = 175,
		['descrip'] = "360安全卫士",
		['isaddicted'] = 0,
	},
	['176']={
		['type'] = 176,
		['descrip'] = "红包",
		['isaddicted'] = 0,
	},
	['177']={
		['type'] = 177,
		['descrip'] = "运营活动;",
		['isaddicted'] = 0,
	},
	['178']={
		['type'] = 178,
		['descrip'] = "团购;",
		['isaddicted'] = 0,
	},
	['179']={
		['type'] = 179,
		['descrip'] = "个人boss;",
		['isaddicted'] = 0,
	},
	['180']={
		['type'] = 180,
		['descrip'] = "新套装",
		['isaddicted'] = 0,
	},
	['181']={
		['type'] = 181,
		['descrip'] = "扩展帮派;",
		['isaddicted'] = 0,
	},
	['182']={
		['type'] = 182,
		['descrip'] = "卫士特权加速",
		['isaddicted'] = 0,
	},
	['183']={
		['type'] = 183,
		['descrip'] = "商店兑换;",
		['isaddicted'] = 0,
	},
	['184']={
		['type'] = 184,
		['descrip'] = "骑战副本",
		['isaddicted'] = 0,
	},
	['185']={
		['type'] = 185,
		['descrip'] = "顺网奖励",
		['isaddicted'] = 0,
	},
	['186']={
		['type'] = 186,
		['descrip'] = "PVP荣耀奖励",
		['isaddicted'] = 0,
	},
	['187']={
		['type'] = 187,
		['descrip'] = "帮派地宫",
		['isaddicted'] = 0,
	},
	['188']={
		['type'] = 188,
		['descrip'] = "sougou奖励",
		['isaddicted'] = 0,
	},
	['189']={
		['type'] = 189,
		['descrip'] = "sougou奖励",
		['isaddicted'] = 0,
	},
	['190']={
		['type'] = 190,
		['descrip'] = "结婚",
		['isaddicted'] = 0,
	},
	['191']={
		['type'] = 191,
		['descrip'] = "生成卷轴时",
		['isaddicted'] = 0,
	},
	['192']={
		['type'] = 192,
		['descrip'] = "圣诞活动",
		['isaddicted'] = 0,
	},
	['193']={
		['type'] = 193,
		['descrip'] = "圣诞捐献奖励",
		['isaddicted'] = 0,
	},
	['194']={
		['type'] = 194,
		['descrip'] = "使用物品",
		['isaddicted'] = 0,
	},
	['195']={
		['type'] = 195,
		['descrip'] = "圣魂",
		['isaddicted'] = 0,
	},
	['196']={
		['type'] = 196,
		['descrip'] = "APP挂机",
		['isaddicted'] = 0,
	},
	['197']={
		['type'] = 197,
		['descrip'] = "挑战副本",
		['isaddicted'] = 0,
	},
};