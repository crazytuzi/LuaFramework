SuperHoleLinkConfig={
	['1']={
		['id'] = 1,
		['num'] = 10,
		['attr'] = "att,300#def,150#hp,1200#super,0.01",
	},
	['2']={
		['id'] = 2,
		['num'] = 20,
		['attr'] = "att,800#def,400#hp,3200#super,0.02",
	},
	['3']={
		['id'] = 3,
		['num'] = 30,
		['attr'] = "att,2000#def,1000#hp,8000#super,0.03",
	},
	['4']={
		['id'] = 4,
		['num'] = 40,
		['attr'] = "att,5000#def,2500#hp,20000#super,0.04",
	},
};