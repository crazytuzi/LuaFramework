GuildbattleselfindexConfig={
	['1']={
		['id'] = 1,
		['rank_range'] = "1,1",
	},
	['2']={
		['id'] = 2,
		['rank_range'] = "2,2",
	},
	['3']={
		['id'] = 3,
		['rank_range'] = "3,3",
	},
	['4']={
		['id'] = 4,
		['rank_range'] = "4,4",
	},
	['5']={
		['id'] = 5,
		['rank_range'] = "5,5",
	},
	['6']={
		['id'] = 6,
		['rank_range'] = "6,10",
	},
	['7']={
		['id'] = 7,
		['rank_range'] = "11,20",
	},
	['8']={
		['id'] = 8,
		['rank_range'] = "21,50",
	},
	['9']={
		['id'] = 9,
		['rank_range'] = "51,100",
	},
	['10']={
		['id'] = 10,
		['rank_range'] = "101,200",
	},
};