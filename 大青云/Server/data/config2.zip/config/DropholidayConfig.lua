DropholidayConfig={
	['200014']={
		['yunying_id'] = 200014,
		['drop_id'] = 36206,
	},
	['10018']={
		['yunying_id'] = 10018,
		['drop_id'] = 36801,
	},
};