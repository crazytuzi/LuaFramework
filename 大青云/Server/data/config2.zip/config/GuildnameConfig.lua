GuildnameConfig={
	['1']={
		['faction_id'] = 1,
		['faction_name'] = "天狼晓月阁",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['2']={
		['faction_id'] = 2,
		['faction_name'] = "剑挥天下",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['3']={
		['faction_id'] = 3,
		['faction_name'] = "噬血盟",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['4']={
		['faction_id'] = 4,
		['faction_name'] = "笑傲乾坤",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['5']={
		['faction_id'] = 5,
		['faction_name'] = "葬爱",
		['faction_notice'] = "帮贡在前20名的每周有特殊奖励",
	},
	['6']={
		['faction_id'] = 6,
		['faction_name'] = "世界主宰",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['7']={
		['faction_id'] = 7,
		['faction_name'] = "执戟破楚天",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['8']={
		['faction_id'] = 8,
		['faction_name'] = "清心寡欲",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['9']={
		['faction_id'] = 9,
		['faction_name'] = "醉意江湖",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['10']={
		['faction_id'] = 10,
		['faction_name'] = "浮生若梦几许痴",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['11']={
		['faction_id'] = 11,
		['faction_name'] = "一统天下",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['12']={
		['faction_id'] = 12,
		['faction_name'] = "傲天神域",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['13']={
		['faction_id'] = 13,
		['faction_name'] = "醉凡尘",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['14']={
		['faction_id'] = 14,
		['faction_name'] = "听花九月",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['15']={
		['faction_id'] = 15,
		['faction_name'] = "墨谭阁",
		['faction_notice'] = "大家努力帮捐，好处多多",
	},
	['16']={
		['faction_id'] = 16,
		['faction_name'] = "只手遮天",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['17']={
		['faction_id'] = 17,
		['faction_name'] = "微微一初夏",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['18']={
		['faction_id'] = 18,
		['faction_name'] = "不灭皇朝",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['19']={
		['faction_id'] = 19,
		['faction_name'] = "摘星阁",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['20']={
		['faction_id'] = 20,
		['faction_name'] = "浪漫烟雨城",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['21']={
		['faction_id'] = 21,
		['faction_name'] = "逐鹿天下",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['22']={
		['faction_id'] = 22,
		['faction_name'] = "湮羽澜约",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['23']={
		['faction_id'] = 23,
		['faction_name'] = "乱战情魔",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['24']={
		['faction_id'] = 24,
		['faction_name'] = "湖心小筑",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['25']={
		['faction_id'] = 25,
		['faction_name'] = "弑血傲天",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['26']={
		['faction_id'] = 26,
		['faction_name'] = "幽水雅阁",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['27']={
		['faction_id'] = 27,
		['faction_name'] = "黑色主义",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['28']={
		['faction_id'] = 28,
		['faction_name'] = "浮华一世",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['29']={
		['faction_id'] = 29,
		['faction_name'] = "逍遥行天下",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['30']={
		['faction_id'] = 30,
		['faction_name'] = "回忆云淡风轻",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['31']={
		['faction_id'] = 31,
		['faction_name'] = "宇春敬明",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['32']={
		['faction_id'] = 32,
		['faction_name'] = "血杏高林",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['33']={
		['faction_id'] = 33,
		['faction_name'] = "远古的守护",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['34']={
		['faction_id'] = 34,
		['faction_name'] = "君临天下",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['35']={
		['faction_id'] = 35,
		['faction_name'] = "剑庐火工头子",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['36']={
		['faction_id'] = 36,
		['faction_name'] = "血染江山",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['37']={
		['faction_id'] = 37,
		['faction_name'] = "国民革命军",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['38']={
		['faction_id'] = 38,
		['faction_name'] = "醉卧沙场谁相伴",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['39']={
		['faction_id'] = 39,
		['faction_name'] = "敢死队",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['40']={
		['faction_id'] = 40,
		['faction_name'] = "小偷公司",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['41']={
		['faction_id'] = 41,
		['faction_name'] = "春哥精英会",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['42']={
		['faction_id'] = 42,
		['faction_name'] = "夜宿艾泽拉斯",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['43']={
		['faction_id'] = 43,
		['faction_name'] = "一切都在于心的距离",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['44']={
		['faction_id'] = 44,
		['faction_name'] = "众神之巅",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['45']={
		['faction_id'] = 45,
		['faction_name'] = "宅腐同萌",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['46']={
		['faction_id'] = 46,
		['faction_name'] = "惟有阑干",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['47']={
		['faction_id'] = 47,
		['faction_name'] = "抱影无眠",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['48']={
		['faction_id'] = 48,
		['faction_name'] = "停灯向晓",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['49']={
		['faction_id'] = 49,
		['faction_name'] = "留香阁",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['50']={
		['faction_id'] = 50,
		['faction_name'] = "花容天下",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['51']={
		['faction_id'] = 51,
		['faction_name'] = "拆迁办",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['52']={
		['faction_id'] = 52,
		['faction_name'] = "御风‖战红颜",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['53']={
		['faction_id'] = 53,
		['faction_name'] = "为你熬翔",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['54']={
		['faction_id'] = 54,
		['faction_name'] = "愚人独守空世界",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['55']={
		['faction_id'] = 55,
		['faction_name'] = "被风遗忘的夏天",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['56']={
		['faction_id'] = 56,
		['faction_name'] = "自挂东南枝",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['57']={
		['faction_id'] = 57,
		['faction_name'] = "仇敌三千又何妨",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['58']={
		['faction_id'] = 58,
		['faction_name'] = "傲视群雄",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['59']={
		['faction_id'] = 59,
		['faction_name'] = "霸气天下",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['60']={
		['faction_id'] = 60,
		['faction_name'] = "冰凝城夏",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['61']={
		['faction_id'] = 61,
		['faction_name'] = "猥琐小队",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['62']={
		['faction_id'] = 62,
		['faction_name'] = "寒舍山房",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['63']={
		['faction_id'] = 63,
		['faction_name'] = "自编自导自演",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['64']={
		['faction_id'] = 64,
		['faction_name'] = "你我敌不过的岁月",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['65']={
		['faction_id'] = 65,
		['faction_name'] = "誓水之滨",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['66']={
		['faction_id'] = 66,
		['faction_name'] = "魔幻九王",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['67']={
		['faction_id'] = 67,
		['faction_name'] = "天下凯旋",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['68']={
		['faction_id'] = 68,
		['faction_name'] = "环碧小筑",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['69']={
		['faction_id'] = 69,
		['faction_name'] = "男人要霸气",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['70']={
		['faction_id'] = 70,
		['faction_name'] = "云淡风轻",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['71']={
		['faction_id'] = 71,
		['faction_name'] = "战愤王朝",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['72']={
		['faction_id'] = 72,
		['faction_name'] = "VIP皇朝风云",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['73']={
		['faction_id'] = 73,
		['faction_name'] = "微笑的起点",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['74']={
		['faction_id'] = 74,
		['faction_name'] = "恋她",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['75']={
		['faction_id'] = 75,
		['faction_name'] = "谁的眼泪在飞",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['76']={
		['faction_id'] = 76,
		['faction_name'] = "社会姐你狠淡定",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['77']={
		['faction_id'] = 77,
		['faction_name'] = "晓月燃霜",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['78']={
		['faction_id'] = 78,
		['faction_name'] = "秋夕遗梦",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['79']={
		['faction_id'] = 79,
		['faction_name'] = "枫葬花魂",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['80']={
		['faction_id'] = 80,
		['faction_name'] = "水阁家族",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['81']={
		['faction_id'] = 81,
		['faction_name'] = "誓永血盟",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['82']={
		['faction_id'] = 82,
		['faction_name'] = "梦幻情缘",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['83']={
		['faction_id'] = 83,
		['faction_name'] = "徽风古韵",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['84']={
		['faction_id'] = 84,
		['faction_name'] = "荣耀",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['85']={
		['faction_id'] = 85,
		['faction_name'] = "潇湘雨轩",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['86']={
		['faction_id'] = 86,
		['faction_name'] = "枫雪海",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['87']={
		['faction_id'] = 87,
		['faction_name'] = "烛堡",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['88']={
		['faction_id'] = 88,
		['faction_name'] = "万事屋",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
	['89']={
		['faction_id'] = 89,
		['faction_name'] = "醉泉乡",
		['faction_notice'] = "十步杀一人， 千里不留行。事了拂衣去，深藏身与名。",
	},
	['90']={
		['faction_id'] = 90,
		['faction_name'] = "咒泉乡",
		['faction_notice'] = "我们掌控全服的暴力，收小弟带武器这是我们的领地",
	},
	['91']={
		['faction_id'] = 91,
		['faction_name'] = "啸龙居",
		['faction_notice'] = "帮会是咱家，升级靠大家，帮战要参加，日常使劲刷",
	},
	['92']={
		['faction_id'] = 92,
		['faction_name'] = "猜心园",
		['faction_notice'] = "高举无产阶级革命旗帜。紧紧的团结在党国必胜周围。",
	},
	['93']={
		['faction_id'] = 93,
		['faction_name'] = "云眉栈",
		['faction_notice'] = "这里是智者的舞台 犹豫的人走开",
	},
	['94']={
		['faction_id'] = 94,
		['faction_name'] = "悦兰芳",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['95']={
		['faction_id'] = 95,
		['faction_name'] = "定禅天",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['96']={
		['faction_id'] = 96,
		['faction_name'] = "萧然蓝阁",
		['faction_notice'] = "我们只看重兄弟，兄弟就是我们",
	},
	['97']={
		['faction_id'] = 97,
		['faction_name'] = "浴火涅盘",
		['faction_notice'] = "希望帮友们就像黄风白雪一样， 身体流着同样的血",
	},
	['98']={
		['faction_id'] = 98,
		['faction_name'] = "天意缘散",
		['faction_notice'] = "三天不上线会清人，希望我们共同努力，打造全服第一帮",
	},
	['99']={
		['faction_id'] = 99,
		['faction_name'] = "清风阁",
		['faction_notice'] = "黄风万里动云天， 白波九道流雪山",
	},
	['100']={
		['faction_id'] = 100,
		['faction_name'] = "爆风王朝",
		['faction_notice'] = "帮贡在前21名的每周有特殊奖励",
	},
};