HomepupilqualityConfig={
	['1']={
		['xunxiantaiLv'] = 1,
		['pupilQualityRange'] = "1000,200,10,1,0",
	},
	['2']={
		['xunxiantaiLv'] = 2,
		['pupilQualityRange'] = "950,250,15,2,0",
	},
	['3']={
		['xunxiantaiLv'] = 3,
		['pupilQualityRange'] = "900,300,20,3,0",
	},
	['4']={
		['xunxiantaiLv'] = 4,
		['pupilQualityRange'] = "800,400,25,4,0",
	},
	['5']={
		['xunxiantaiLv'] = 5,
		['pupilQualityRange'] = "700,500,30,5,0",
	},
	['6']={
		['xunxiantaiLv'] = 6,
		['pupilQualityRange'] = "700,500,30,5,0",
	},
	['7']={
		['xunxiantaiLv'] = 7,
		['pupilQualityRange'] = "700,500,30,5,0",
	},
	['8']={
		['xunxiantaiLv'] = 8,
		['pupilQualityRange'] = "700,500,30,5,0",
	},
	['9']={
		['xunxiantaiLv'] = 9,
		['pupilQualityRange'] = "700,500,30,5,0",
	},
	['10']={
		['xunxiantaiLv'] = 10,
		['pupilQualityRange'] = "700,500,30,5,0",
	},
};