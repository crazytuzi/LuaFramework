ZhuanshengConfig={
	['1']={
		['id'] = 1,
		['level'] = 100,
		['attr'] = "att,240#def,120#hp,960#dodge,72#hit,72#cri,72#defcri,72",
		['mapid'] = 10340004,
		['EndStoryId'] = 203003,
		['money'] = 20,
	},
	['2']={
		['id'] = 2,
		['level'] = 130,
		['attr'] = "att,360#def,180#hp,1440#dodge,100#hit,100#cri,100#defcri,100",
		['mapid'] = 10340006,
		['EndStoryId'] = 303009,
		['money'] = 40,
	},
	['3']={
		['id'] = 3,
		['level'] = 150,
		['attr'] = "att,600#def,300#hp,2400#dodge,180#hit,180#cri,180#defcri,180",
		['mapid'] = 10340007,
		['EndStoryId'] = 403012,
		['money'] = 60,
	},
};