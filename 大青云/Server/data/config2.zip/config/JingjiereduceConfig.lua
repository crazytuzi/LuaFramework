JingjiereduceConfig={
	['1']={
		['level'] = 1,
		['reduce_percent'] = 5,
	},
	['2']={
		['level'] = 2,
		['reduce_percent'] = 10,
	},
	['3']={
		['level'] = 3,
		['reduce_percent'] = 20,
	},
	['4']={
		['level'] = 4,
		['reduce_percent'] = 30,
	},
	['5']={
		['level'] = 5,
		['reduce_percent'] = 40,
	},
	['6']={
		['level'] = 6,
		['reduce_percent'] = 50,
	},
	['7']={
		['level'] = 7,
		['reduce_percent'] = 60,
	},
	['8']={
		['level'] = 8,
		['reduce_percent'] = 70,
	},
	['9']={
		['level'] = 9,
		['reduce_percent'] = 80,
	},
	['10']={
		['level'] = 10,
		['reduce_percent'] = 90,
	},
};