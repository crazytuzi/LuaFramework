ZhanyincostConfig={
	['1']={
		['id'] = 1,
		['cost'] = 50000,
		['itemid'] = 0,
	},
	['2']={
		['id'] = 2,
		['cost'] = 20,
		['itemid'] = 0,
	},
};