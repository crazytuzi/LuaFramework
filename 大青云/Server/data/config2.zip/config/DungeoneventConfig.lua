DungeoneventConfig={
	['1']={
		['id'] = 1,
		['reward_exp'] = 1000,
		['reward_item'] = "14,10000",
	},
	['2']={
		['id'] = 2,
		['reward_exp'] = 2000,
		['reward_item'] = "14,20000",
	},
	['3']={
		['id'] = 3,
		['reward_exp'] = 3000,
		['reward_item'] = "14,30000",
	},
};