StrenlinkConfig={
	['1']={
		['id'] = 1,
		['level'] = 44,
		['attr'] = "att,45#def,23#hp,450",
	},
	['2']={
		['id'] = 2,
		['level'] = 88,
		['attr'] = "att,90#def,45#hp,900",
	},
	['3']={
		['id'] = 3,
		['level'] = 132,
		['attr'] = "att,180#def,90#hp,1800",
	},
	['4']={
		['id'] = 4,
		['level'] = 176,
		['attr'] = "att,300#def,150#hp,3000",
	},
	['5']={
		['id'] = 5,
		['level'] = 220,
		['attr'] = "att,390#def,195#hp,3900",
	},
	['6']={
		['id'] = 6,
		['level'] = 264,
		['attr'] = "att,495#def,248#hp,4950",
	},
};