Questagora_qualityConfig={
	['1']={
		['id'] = 1,
		['quality'] = 1,
		['house'] = "1,10000",
		['reward'] = "5",
		['certain_num'] = 0,
		['weight'] = 0,
	},
	['2']={
		['id'] = 2,
		['quality'] = 2,
		['house'] = "2,10000",
		['reward'] = "4",
		['certain_num'] = 0,
		['weight'] = 0,
	},
	['3']={
		['id'] = 3,
		['quality'] = 3,
		['house'] = "3,10000",
		['reward'] = "1#2#3",
		['certain_num'] = 4,
		['weight'] = 100,
	},
};