HomepupilexpitemConfig={
	['1']={
		['id'] = 1,
		['itemid'] = 110220038,
		['image_man'] = "弟子经验书(中)",
		['expType'] = 0,
		['expNum'] = 10000,
	},
	['2']={
		['id'] = 2,
		['itemid'] = 110220039,
		['image_man'] = "弟子经验书(高)",
		['expType'] = 0,
		['expNum'] = 100000,
	},
	['3']={
		['id'] = 3,
		['itemid'] = 110220040,
		['image_man'] = "弟子经验书(极)",
		['expType'] = 0,
		['expNum'] = 5000000,
	},
	['4']={
		['id'] = 4,
		['itemid'] = 110220050,
		['image_man'] = "弟子经验丹",
		['expType'] = 1,
		['expNum'] = 100,
	},
};