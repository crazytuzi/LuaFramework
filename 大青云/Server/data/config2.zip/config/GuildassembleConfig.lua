GuildassembleConfig={
	['1']={
		['id'] = 1,
	},
	['2']={
		['id'] = 2,
	},
};