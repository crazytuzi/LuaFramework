CitywarConfig={
	['1']={
		['id'] = 1,
		['title'] = 12001,
		['buff'] = "1013007,1013008",
		['horseskn'] = 203,
	},
	['2']={
		['id'] = 2,
		['title'] = 12003,
		['buff'] = "",
		['horseskn'] = 0,
	},
	['3']={
		['id'] = 3,
		['title'] = 12004,
		['buff'] = "",
		['horseskn'] = 0,
	},
	['4']={
		['id'] = 4,
		['title'] = 12005,
		['buff'] = "",
		['horseskn'] = 0,
	},
	['5']={
		['id'] = 5,
		['title'] = 12006,
		['buff'] = "",
		['horseskn'] = 0,
	},
	['6']={
		['id'] = 6,
		['title'] = 12007,
		['buff'] = "",
		['horseskn'] = 0,
	},
	['7']={
		['id'] = 7,
		['title'] = 12002,
		['buff'] = "",
		['horseskn'] = 0,
	},
};