SpecialAttrfightConfig={
	['hp']={
		['str'] = "hp",
		['val1'] = 0,
		['val2'] = 0,
	},
	['att']={
		['str'] = "att",
		['val1'] = 0,
		['val2'] = 0,
	},
	['def']={
		['str'] = "def",
		['val1'] = 0,
		['val2'] = 0,
	},
	['subdef']={
		['str'] = "subdef",
		['val1'] = 0,
		['val2'] = 0,
	},
	['absatt']={
		['str'] = "absatt",
		['val1'] = 0,
		['val2'] = 0,
	},
	['hit']={
		['str'] = "hit",
		['val1'] = 0,
		['val2'] = 0,
	},
	['dodge']={
		['str'] = "dodge",
		['val1'] = 0,
		['val2'] = 0,
	},
	['cri']={
		['str'] = "cri",
		['val1'] = 0,
		['val2'] = 0,
	},
	['defcri']={
		['str'] = "defcri",
		['val1'] = 0,
		['val2'] = 0,
	},
	['parryvalue']={
		['str'] = "parryvalue",
		['val1'] = 0,
		['val2'] = 0,
	},
	['defparry']={
		['str'] = "defparry",
		['val1'] = 0,
		['val2'] = 0,
	},
	['crivalue']={
		['str'] = "crivalue",
		['val1'] = 0,
		['val2'] = 0,
	},
	['subcri']={
		['str'] = "subcri",
		['val1'] = 0,
		['val2'] = 0,
	},
	['supervalue']={
		['str'] = "supervalue",
		['val1'] = 0,
		['val2'] = 0,
	},
	['hit_rate']={
		['str'] = "hit_rate",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['dodge_rate']={
		['str'] = "dodge_rate",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['cri_rate']={
		['str'] = "cri_rate",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['defcri_rate']={
		['str'] = "defcri_rate",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['parry_rate']={
		['str'] = "parry_rate",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['defparry_rate']={
		['str'] = "defparry_rate",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['adddamage']={
		['str'] = "adddamage",
		['val1'] = 0.11,
		['val2'] = 0,
	},
	['subdamage']={
		['str'] = "subdamage",
		['val1'] = 0.09,
		['val2'] = 0,
	},
	['reflex']={
		['str'] = "reflex",
		['val1'] = 0.5,
		['val2'] = 0,
	},
	['super']={
		['str'] = "super",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['adddamagemonx']={
		['str'] = "adddamagemonx",
		['val1'] = 0.1,
		['val2'] = 0,
	},
	['adddamagebossx']={
		['str'] = "adddamagebossx",
		['val1'] = 0.25,
		['val2'] = 0,
	},
	['killhp']={
		['str'] = "killhp",
		['val1'] = 2.5000000000000001E-2,
		['val2'] = 0,
	},
	['hithp']={
		['str'] = "hithp",
		['val1'] = 0.05,
		['val2'] = 0,
	},
	['shpre']={
		['str'] = "shpre",
		['val1'] = 0.05,
		['val2'] = 0,
	},
	['igdef']={
		['str'] = "igdef",
		['val1'] = 1.1000000000000001,
		['val2'] = 0,
	},
	['ignoredmg']={
		['str'] = "ignoredmg",
		['val1'] = 0,
		['val2'] = 0,
	},
	['defjiansu']={
		['str'] = "defjiansu",
		['val1'] = 0,
		['val2'] = 0,
	},
	['defdingshen']={
		['str'] = "defdingshen",
		['val1'] = 0,
		['val2'] = 0,
	},
	['defxuanuun']={
		['str'] = "defxuanuun",
		['val1'] = 0,
		['val2'] = 0,
	},
	['defchenmo']={
		['str'] = "defchenmo",
		['val1'] = 0,
		['val2'] = 0,
	},
	['parryx']={
		['str'] = "parryx",
		['val1'] = 0,
		['val2'] = 0,
	},
	['parryvaluex']={
		['str'] = "parryvaluex",
		['val1'] = 0,
		['val2'] = 0,
	},
	['superx']={
		['str'] = "superx",
		['val1'] = 0,
		['val2'] = 0,
	},
};