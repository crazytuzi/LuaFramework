GoldbossparConfig={
	['1']={
		['id'] = 1,
		['mapid'] = 11402001,
		['boss_enter'] = 60005,
		['boss_skill'] = "",
		['skill_interval'] = 0,
		['mark_A'] = 60003,
		['mark_B'] = 60004,
		['hook_A'] = 60005,
		['hook_B'] = 60002,
		['reward_hp_lv_set'] = "90#80#70#60#50#40#30#20#10#0",
	},
};