BeicangjiescoreConfig={
	['13020001']={
		['monster'] = 13020001,
		['score'] = 50,
	},
	['13020002']={
		['monster'] = 13020002,
		['score'] = 100,
	},
};