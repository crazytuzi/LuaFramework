HomepupilexpConfig={
	['1']={
		['pupilLv'] = 1,
		['pupilExp'] = 100,
	},
	['2']={
		['pupilLv'] = 2,
		['pupilExp'] = 200,
	},
	['3']={
		['pupilLv'] = 3,
		['pupilExp'] = 300,
	},
	['4']={
		['pupilLv'] = 4,
		['pupilExp'] = 400,
	},
	['5']={
		['pupilLv'] = 5,
		['pupilExp'] = 500,
	},
	['6']={
		['pupilLv'] = 6,
		['pupilExp'] = 600,
	},
	['7']={
		['pupilLv'] = 7,
		['pupilExp'] = 700,
	},
	['8']={
		['pupilLv'] = 8,
		['pupilExp'] = 800,
	},
	['9']={
		['pupilLv'] = 9,
		['pupilExp'] = 900,
	},
	['10']={
		['pupilLv'] = 10,
		['pupilExp'] = 1000,
	},
	['11']={
		['pupilLv'] = 11,
		['pupilExp'] = 1100,
	},
	['12']={
		['pupilLv'] = 12,
		['pupilExp'] = 1200,
	},
	['13']={
		['pupilLv'] = 13,
		['pupilExp'] = 1300,
	},
	['14']={
		['pupilLv'] = 14,
		['pupilExp'] = 1400,
	},
	['15']={
		['pupilLv'] = 15,
		['pupilExp'] = 1500,
	},
	['16']={
		['pupilLv'] = 16,
		['pupilExp'] = 1600,
	},
	['17']={
		['pupilLv'] = 17,
		['pupilExp'] = 1700,
	},
	['18']={
		['pupilLv'] = 18,
		['pupilExp'] = 1800,
	},
	['19']={
		['pupilLv'] = 19,
		['pupilExp'] = 1900,
	},
	['20']={
		['pupilLv'] = 20,
		['pupilExp'] = 2000,
	},
	['21']={
		['pupilLv'] = 21,
		['pupilExp'] = 2100,
	},
	['22']={
		['pupilLv'] = 22,
		['pupilExp'] = 2200,
	},
	['23']={
		['pupilLv'] = 23,
		['pupilExp'] = 2300,
	},
	['24']={
		['pupilLv'] = 24,
		['pupilExp'] = 2400,
	},
	['25']={
		['pupilLv'] = 25,
		['pupilExp'] = 2500,
	},
	['26']={
		['pupilLv'] = 26,
		['pupilExp'] = 2600,
	},
	['27']={
		['pupilLv'] = 27,
		['pupilExp'] = 2700,
	},
	['28']={
		['pupilLv'] = 28,
		['pupilExp'] = 2800,
	},
	['29']={
		['pupilLv'] = 29,
		['pupilExp'] = 2900,
	},
	['30']={
		['pupilLv'] = 30,
		['pupilExp'] = 3000,
	},
	['31']={
		['pupilLv'] = 31,
		['pupilExp'] = 3100,
	},
	['32']={
		['pupilLv'] = 32,
		['pupilExp'] = 3200,
	},
	['33']={
		['pupilLv'] = 33,
		['pupilExp'] = 3300,
	},
	['34']={
		['pupilLv'] = 34,
		['pupilExp'] = 3400,
	},
	['35']={
		['pupilLv'] = 35,
		['pupilExp'] = 3500,
	},
	['36']={
		['pupilLv'] = 36,
		['pupilExp'] = 3600,
	},
	['37']={
		['pupilLv'] = 37,
		['pupilExp'] = 3700,
	},
	['38']={
		['pupilLv'] = 38,
		['pupilExp'] = 3800,
	},
	['39']={
		['pupilLv'] = 39,
		['pupilExp'] = 3900,
	},
	['40']={
		['pupilLv'] = 40,
		['pupilExp'] = 4000,
	},
	['41']={
		['pupilLv'] = 41,
		['pupilExp'] = 4100,
	},
	['42']={
		['pupilLv'] = 42,
		['pupilExp'] = 4200,
	},
	['43']={
		['pupilLv'] = 43,
		['pupilExp'] = 4300,
	},
	['44']={
		['pupilLv'] = 44,
		['pupilExp'] = 4400,
	},
	['45']={
		['pupilLv'] = 45,
		['pupilExp'] = 4500,
	},
	['46']={
		['pupilLv'] = 46,
		['pupilExp'] = 4600,
	},
	['47']={
		['pupilLv'] = 47,
		['pupilExp'] = 4700,
	},
	['48']={
		['pupilLv'] = 48,
		['pupilExp'] = 4800,
	},
	['49']={
		['pupilLv'] = 49,
		['pupilExp'] = 4900,
	},
	['50']={
		['pupilLv'] = 50,
		['pupilExp'] = 5000,
	},
	['51']={
		['pupilLv'] = 51,
		['pupilExp'] = 5100,
	},
	['52']={
		['pupilLv'] = 52,
		['pupilExp'] = 5200,
	},
	['53']={
		['pupilLv'] = 53,
		['pupilExp'] = 5300,
	},
	['54']={
		['pupilLv'] = 54,
		['pupilExp'] = 5400,
	},
	['55']={
		['pupilLv'] = 55,
		['pupilExp'] = 5500,
	},
	['56']={
		['pupilLv'] = 56,
		['pupilExp'] = 5600,
	},
	['57']={
		['pupilLv'] = 57,
		['pupilExp'] = 5700,
	},
	['58']={
		['pupilLv'] = 58,
		['pupilExp'] = 5800,
	},
	['59']={
		['pupilLv'] = 59,
		['pupilExp'] = 5900,
	},
	['60']={
		['pupilLv'] = 60,
		['pupilExp'] = 6000,
	},
	['61']={
		['pupilLv'] = 61,
		['pupilExp'] = 6100,
	},
	['62']={
		['pupilLv'] = 62,
		['pupilExp'] = 6200,
	},
	['63']={
		['pupilLv'] = 63,
		['pupilExp'] = 6300,
	},
	['64']={
		['pupilLv'] = 64,
		['pupilExp'] = 6400,
	},
	['65']={
		['pupilLv'] = 65,
		['pupilExp'] = 6500,
	},
	['66']={
		['pupilLv'] = 66,
		['pupilExp'] = 6600,
	},
	['67']={
		['pupilLv'] = 67,
		['pupilExp'] = 6700,
	},
	['68']={
		['pupilLv'] = 68,
		['pupilExp'] = 6800,
	},
	['69']={
		['pupilLv'] = 69,
		['pupilExp'] = 6900,
	},
	['70']={
		['pupilLv'] = 70,
		['pupilExp'] = 7000,
	},
	['71']={
		['pupilLv'] = 71,
		['pupilExp'] = 7100,
	},
	['72']={
		['pupilLv'] = 72,
		['pupilExp'] = 7200,
	},
	['73']={
		['pupilLv'] = 73,
		['pupilExp'] = 7300,
	},
	['74']={
		['pupilLv'] = 74,
		['pupilExp'] = 7400,
	},
	['75']={
		['pupilLv'] = 75,
		['pupilExp'] = 7500,
	},
	['76']={
		['pupilLv'] = 76,
		['pupilExp'] = 7600,
	},
	['77']={
		['pupilLv'] = 77,
		['pupilExp'] = 7700,
	},
	['78']={
		['pupilLv'] = 78,
		['pupilExp'] = 7800,
	},
	['79']={
		['pupilLv'] = 79,
		['pupilExp'] = 7900,
	},
	['80']={
		['pupilLv'] = 80,
		['pupilExp'] = 8000,
	},
	['81']={
		['pupilLv'] = 81,
		['pupilExp'] = 8100,
	},
	['82']={
		['pupilLv'] = 82,
		['pupilExp'] = 8200,
	},
	['83']={
		['pupilLv'] = 83,
		['pupilExp'] = 8300,
	},
	['84']={
		['pupilLv'] = 84,
		['pupilExp'] = 8400,
	},
	['85']={
		['pupilLv'] = 85,
		['pupilExp'] = 8500,
	},
	['86']={
		['pupilLv'] = 86,
		['pupilExp'] = 8600,
	},
	['87']={
		['pupilLv'] = 87,
		['pupilExp'] = 8700,
	},
	['88']={
		['pupilLv'] = 88,
		['pupilExp'] = 8800,
	},
	['89']={
		['pupilLv'] = 89,
		['pupilExp'] = 8900,
	},
	['90']={
		['pupilLv'] = 90,
		['pupilExp'] = 9000,
	},
	['91']={
		['pupilLv'] = 91,
		['pupilExp'] = 9100,
	},
	['92']={
		['pupilLv'] = 92,
		['pupilExp'] = 9200,
	},
	['93']={
		['pupilLv'] = 93,
		['pupilExp'] = 9300,
	},
	['94']={
		['pupilLv'] = 94,
		['pupilExp'] = 9400,
	},
	['95']={
		['pupilLv'] = 95,
		['pupilExp'] = 9500,
	},
	['96']={
		['pupilLv'] = 96,
		['pupilExp'] = 9600,
	},
	['97']={
		['pupilLv'] = 97,
		['pupilExp'] = 9700,
	},
	['98']={
		['pupilLv'] = 98,
		['pupilExp'] = 9800,
	},
	['99']={
		['pupilLv'] = 99,
		['pupilExp'] = 9900,
	},
	['100']={
		['pupilLv'] = 100,
		['pupilExp'] = 10000,
	},
	['101']={
		['pupilLv'] = 101,
		['pupilExp'] = 10100,
	},
	['102']={
		['pupilLv'] = 102,
		['pupilExp'] = 10200,
	},
	['103']={
		['pupilLv'] = 103,
		['pupilExp'] = 10300,
	},
	['104']={
		['pupilLv'] = 104,
		['pupilExp'] = 10400,
	},
	['105']={
		['pupilLv'] = 105,
		['pupilExp'] = 10500,
	},
	['106']={
		['pupilLv'] = 106,
		['pupilExp'] = 10600,
	},
	['107']={
		['pupilLv'] = 107,
		['pupilExp'] = 10700,
	},
	['108']={
		['pupilLv'] = 108,
		['pupilExp'] = 10800,
	},
	['109']={
		['pupilLv'] = 109,
		['pupilExp'] = 10900,
	},
	['110']={
		['pupilLv'] = 110,
		['pupilExp'] = 11000,
	},
	['111']={
		['pupilLv'] = 111,
		['pupilExp'] = 11100,
	},
	['112']={
		['pupilLv'] = 112,
		['pupilExp'] = 11200,
	},
	['113']={
		['pupilLv'] = 113,
		['pupilExp'] = 11300,
	},
	['114']={
		['pupilLv'] = 114,
		['pupilExp'] = 11400,
	},
	['115']={
		['pupilLv'] = 115,
		['pupilExp'] = 11500,
	},
	['116']={
		['pupilLv'] = 116,
		['pupilExp'] = 11600,
	},
	['117']={
		['pupilLv'] = 117,
		['pupilExp'] = 11700,
	},
	['118']={
		['pupilLv'] = 118,
		['pupilExp'] = 11800,
	},
	['119']={
		['pupilLv'] = 119,
		['pupilExp'] = 11900,
	},
	['120']={
		['pupilLv'] = 120,
		['pupilExp'] = 12000,
	},
	['121']={
		['pupilLv'] = 121,
		['pupilExp'] = 12100,
	},
	['122']={
		['pupilLv'] = 122,
		['pupilExp'] = 12200,
	},
	['123']={
		['pupilLv'] = 123,
		['pupilExp'] = 12300,
	},
	['124']={
		['pupilLv'] = 124,
		['pupilExp'] = 12400,
	},
	['125']={
		['pupilLv'] = 125,
		['pupilExp'] = 12500,
	},
	['126']={
		['pupilLv'] = 126,
		['pupilExp'] = 12600,
	},
	['127']={
		['pupilLv'] = 127,
		['pupilExp'] = 12700,
	},
	['128']={
		['pupilLv'] = 128,
		['pupilExp'] = 12800,
	},
	['129']={
		['pupilLv'] = 129,
		['pupilExp'] = 12900,
	},
	['130']={
		['pupilLv'] = 130,
		['pupilExp'] = 13000,
	},
	['131']={
		['pupilLv'] = 131,
		['pupilExp'] = 13100,
	},
	['132']={
		['pupilLv'] = 132,
		['pupilExp'] = 13200,
	},
	['133']={
		['pupilLv'] = 133,
		['pupilExp'] = 13300,
	},
	['134']={
		['pupilLv'] = 134,
		['pupilExp'] = 13400,
	},
	['135']={
		['pupilLv'] = 135,
		['pupilExp'] = 13500,
	},
	['136']={
		['pupilLv'] = 136,
		['pupilExp'] = 13600,
	},
	['137']={
		['pupilLv'] = 137,
		['pupilExp'] = 13700,
	},
	['138']={
		['pupilLv'] = 138,
		['pupilExp'] = 13800,
	},
	['139']={
		['pupilLv'] = 139,
		['pupilExp'] = 13900,
	},
	['140']={
		['pupilLv'] = 140,
		['pupilExp'] = 14000,
	},
	['141']={
		['pupilLv'] = 141,
		['pupilExp'] = 14100,
	},
	['142']={
		['pupilLv'] = 142,
		['pupilExp'] = 14200,
	},
	['143']={
		['pupilLv'] = 143,
		['pupilExp'] = 14300,
	},
	['144']={
		['pupilLv'] = 144,
		['pupilExp'] = 14400,
	},
	['145']={
		['pupilLv'] = 145,
		['pupilExp'] = 14500,
	},
	['146']={
		['pupilLv'] = 146,
		['pupilExp'] = 14600,
	},
	['147']={
		['pupilLv'] = 147,
		['pupilExp'] = 14700,
	},
	['148']={
		['pupilLv'] = 148,
		['pupilExp'] = 14800,
	},
	['149']={
		['pupilLv'] = 149,
		['pupilExp'] = 14900,
	},
	['150']={
		['pupilLv'] = 150,
		['pupilExp'] = 15000,
	},
	['151']={
		['pupilLv'] = 151,
		['pupilExp'] = 15100,
	},
	['152']={
		['pupilLv'] = 152,
		['pupilExp'] = 15200,
	},
	['153']={
		['pupilLv'] = 153,
		['pupilExp'] = 15300,
	},
	['154']={
		['pupilLv'] = 154,
		['pupilExp'] = 15400,
	},
	['155']={
		['pupilLv'] = 155,
		['pupilExp'] = 15500,
	},
	['156']={
		['pupilLv'] = 156,
		['pupilExp'] = 15600,
	},
	['157']={
		['pupilLv'] = 157,
		['pupilExp'] = 15700,
	},
	['158']={
		['pupilLv'] = 158,
		['pupilExp'] = 15800,
	},
	['159']={
		['pupilLv'] = 159,
		['pupilExp'] = 15900,
	},
	['160']={
		['pupilLv'] = 160,
		['pupilExp'] = 16000,
	},
	['161']={
		['pupilLv'] = 161,
		['pupilExp'] = 16100,
	},
	['162']={
		['pupilLv'] = 162,
		['pupilExp'] = 16200,
	},
	['163']={
		['pupilLv'] = 163,
		['pupilExp'] = 16300,
	},
	['164']={
		['pupilLv'] = 164,
		['pupilExp'] = 16400,
	},
	['165']={
		['pupilLv'] = 165,
		['pupilExp'] = 16500,
	},
	['166']={
		['pupilLv'] = 166,
		['pupilExp'] = 16600,
	},
	['167']={
		['pupilLv'] = 167,
		['pupilExp'] = 16700,
	},
	['168']={
		['pupilLv'] = 168,
		['pupilExp'] = 16800,
	},
	['169']={
		['pupilLv'] = 169,
		['pupilExp'] = 16900,
	},
	['170']={
		['pupilLv'] = 170,
		['pupilExp'] = 17000,
	},
	['171']={
		['pupilLv'] = 171,
		['pupilExp'] = 17100,
	},
	['172']={
		['pupilLv'] = 172,
		['pupilExp'] = 17200,
	},
	['173']={
		['pupilLv'] = 173,
		['pupilExp'] = 17300,
	},
	['174']={
		['pupilLv'] = 174,
		['pupilExp'] = 17400,
	},
	['175']={
		['pupilLv'] = 175,
		['pupilExp'] = 17500,
	},
	['176']={
		['pupilLv'] = 176,
		['pupilExp'] = 17600,
	},
	['177']={
		['pupilLv'] = 177,
		['pupilExp'] = 17700,
	},
	['178']={
		['pupilLv'] = 178,
		['pupilExp'] = 17800,
	},
	['179']={
		['pupilLv'] = 179,
		['pupilExp'] = 17900,
	},
	['180']={
		['pupilLv'] = 180,
		['pupilExp'] = 18000,
	},
	['181']={
		['pupilLv'] = 181,
		['pupilExp'] = 18100,
	},
	['182']={
		['pupilLv'] = 182,
		['pupilExp'] = 18200,
	},
	['183']={
		['pupilLv'] = 183,
		['pupilExp'] = 18300,
	},
	['184']={
		['pupilLv'] = 184,
		['pupilExp'] = 18400,
	},
	['185']={
		['pupilLv'] = 185,
		['pupilExp'] = 18500,
	},
	['186']={
		['pupilLv'] = 186,
		['pupilExp'] = 18600,
	},
	['187']={
		['pupilLv'] = 187,
		['pupilExp'] = 18700,
	},
	['188']={
		['pupilLv'] = 188,
		['pupilExp'] = 18800,
	},
	['189']={
		['pupilLv'] = 189,
		['pupilExp'] = 18900,
	},
	['190']={
		['pupilLv'] = 190,
		['pupilExp'] = 19000,
	},
	['191']={
		['pupilLv'] = 191,
		['pupilExp'] = 19100,
	},
	['192']={
		['pupilLv'] = 192,
		['pupilExp'] = 19200,
	},
	['193']={
		['pupilLv'] = 193,
		['pupilExp'] = 19300,
	},
	['194']={
		['pupilLv'] = 194,
		['pupilExp'] = 19400,
	},
	['195']={
		['pupilLv'] = 195,
		['pupilExp'] = 19500,
	},
	['196']={
		['pupilLv'] = 196,
		['pupilExp'] = 19600,
	},
	['197']={
		['pupilLv'] = 197,
		['pupilExp'] = 19700,
	},
	['198']={
		['pupilLv'] = 198,
		['pupilExp'] = 19800,
	},
	['199']={
		['pupilLv'] = 199,
		['pupilExp'] = 19900,
	},
	['200']={
		['pupilLv'] = 200,
		['pupilExp'] = 20000,
	},
	['201']={
		['pupilLv'] = 201,
		['pupilExp'] = 20100,
	},
	['202']={
		['pupilLv'] = 202,
		['pupilExp'] = 20200,
	},
	['203']={
		['pupilLv'] = 203,
		['pupilExp'] = 20300,
	},
	['204']={
		['pupilLv'] = 204,
		['pupilExp'] = 20400,
	},
	['205']={
		['pupilLv'] = 205,
		['pupilExp'] = 20500,
	},
	['206']={
		['pupilLv'] = 206,
		['pupilExp'] = 20600,
	},
	['207']={
		['pupilLv'] = 207,
		['pupilExp'] = 20700,
	},
	['208']={
		['pupilLv'] = 208,
		['pupilExp'] = 20800,
	},
	['209']={
		['pupilLv'] = 209,
		['pupilExp'] = 20900,
	},
	['210']={
		['pupilLv'] = 210,
		['pupilExp'] = 21000,
	},
	['211']={
		['pupilLv'] = 211,
		['pupilExp'] = 21100,
	},
	['212']={
		['pupilLv'] = 212,
		['pupilExp'] = 21200,
	},
	['213']={
		['pupilLv'] = 213,
		['pupilExp'] = 21300,
	},
	['214']={
		['pupilLv'] = 214,
		['pupilExp'] = 21400,
	},
	['215']={
		['pupilLv'] = 215,
		['pupilExp'] = 21500,
	},
	['216']={
		['pupilLv'] = 216,
		['pupilExp'] = 21600,
	},
	['217']={
		['pupilLv'] = 217,
		['pupilExp'] = 21700,
	},
	['218']={
		['pupilLv'] = 218,
		['pupilExp'] = 21800,
	},
	['219']={
		['pupilLv'] = 219,
		['pupilExp'] = 21900,
	},
	['220']={
		['pupilLv'] = 220,
		['pupilExp'] = 22000,
	},
	['221']={
		['pupilLv'] = 221,
		['pupilExp'] = 22100,
	},
	['222']={
		['pupilLv'] = 222,
		['pupilExp'] = 22200,
	},
	['223']={
		['pupilLv'] = 223,
		['pupilExp'] = 22300,
	},
	['224']={
		['pupilLv'] = 224,
		['pupilExp'] = 22400,
	},
	['225']={
		['pupilLv'] = 225,
		['pupilExp'] = 22500,
	},
	['226']={
		['pupilLv'] = 226,
		['pupilExp'] = 22600,
	},
	['227']={
		['pupilLv'] = 227,
		['pupilExp'] = 22700,
	},
	['228']={
		['pupilLv'] = 228,
		['pupilExp'] = 22800,
	},
	['229']={
		['pupilLv'] = 229,
		['pupilExp'] = 22900,
	},
	['230']={
		['pupilLv'] = 230,
		['pupilExp'] = 23000,
	},
	['231']={
		['pupilLv'] = 231,
		['pupilExp'] = 23100,
	},
	['232']={
		['pupilLv'] = 232,
		['pupilExp'] = 23200,
	},
	['233']={
		['pupilLv'] = 233,
		['pupilExp'] = 23300,
	},
	['234']={
		['pupilLv'] = 234,
		['pupilExp'] = 23400,
	},
	['235']={
		['pupilLv'] = 235,
		['pupilExp'] = 23500,
	},
	['236']={
		['pupilLv'] = 236,
		['pupilExp'] = 23600,
	},
	['237']={
		['pupilLv'] = 237,
		['pupilExp'] = 23700,
	},
	['238']={
		['pupilLv'] = 238,
		['pupilExp'] = 23800,
	},
	['239']={
		['pupilLv'] = 239,
		['pupilExp'] = 23900,
	},
	['240']={
		['pupilLv'] = 240,
		['pupilExp'] = 24000,
	},
	['241']={
		['pupilLv'] = 241,
		['pupilExp'] = 24100,
	},
	['242']={
		['pupilLv'] = 242,
		['pupilExp'] = 24200,
	},
	['243']={
		['pupilLv'] = 243,
		['pupilExp'] = 24300,
	},
	['244']={
		['pupilLv'] = 244,
		['pupilExp'] = 24400,
	},
	['245']={
		['pupilLv'] = 245,
		['pupilExp'] = 24500,
	},
	['246']={
		['pupilLv'] = 246,
		['pupilExp'] = 24600,
	},
	['247']={
		['pupilLv'] = 247,
		['pupilExp'] = 24700,
	},
	['248']={
		['pupilLv'] = 248,
		['pupilExp'] = 24800,
	},
	['249']={
		['pupilLv'] = 249,
		['pupilExp'] = 24900,
	},
	['250']={
		['pupilLv'] = 250,
		['pupilExp'] = 25000,
	},
	['251']={
		['pupilLv'] = 251,
		['pupilExp'] = 25100,
	},
	['252']={
		['pupilLv'] = 252,
		['pupilExp'] = 25200,
	},
	['253']={
		['pupilLv'] = 253,
		['pupilExp'] = 25300,
	},
	['254']={
		['pupilLv'] = 254,
		['pupilExp'] = 25400,
	},
	['255']={
		['pupilLv'] = 255,
		['pupilExp'] = 25500,
	},
	['256']={
		['pupilLv'] = 256,
		['pupilExp'] = 25600,
	},
	['257']={
		['pupilLv'] = 257,
		['pupilExp'] = 25700,
	},
	['258']={
		['pupilLv'] = 258,
		['pupilExp'] = 25800,
	},
	['259']={
		['pupilLv'] = 259,
		['pupilExp'] = 25900,
	},
	['260']={
		['pupilLv'] = 260,
		['pupilExp'] = 26000,
	},
	['261']={
		['pupilLv'] = 261,
		['pupilExp'] = 26100,
	},
	['262']={
		['pupilLv'] = 262,
		['pupilExp'] = 26200,
	},
	['263']={
		['pupilLv'] = 263,
		['pupilExp'] = 26300,
	},
	['264']={
		['pupilLv'] = 264,
		['pupilExp'] = 26400,
	},
	['265']={
		['pupilLv'] = 265,
		['pupilExp'] = 26500,
	},
	['266']={
		['pupilLv'] = 266,
		['pupilExp'] = 26600,
	},
	['267']={
		['pupilLv'] = 267,
		['pupilExp'] = 26700,
	},
	['268']={
		['pupilLv'] = 268,
		['pupilExp'] = 26800,
	},
	['269']={
		['pupilLv'] = 269,
		['pupilExp'] = 26900,
	},
	['270']={
		['pupilLv'] = 270,
		['pupilExp'] = 27000,
	},
	['271']={
		['pupilLv'] = 271,
		['pupilExp'] = 27100,
	},
	['272']={
		['pupilLv'] = 272,
		['pupilExp'] = 27200,
	},
	['273']={
		['pupilLv'] = 273,
		['pupilExp'] = 27300,
	},
	['274']={
		['pupilLv'] = 274,
		['pupilExp'] = 27400,
	},
	['275']={
		['pupilLv'] = 275,
		['pupilExp'] = 27500,
	},
	['276']={
		['pupilLv'] = 276,
		['pupilExp'] = 27600,
	},
	['277']={
		['pupilLv'] = 277,
		['pupilExp'] = 27700,
	},
	['278']={
		['pupilLv'] = 278,
		['pupilExp'] = 27800,
	},
	['279']={
		['pupilLv'] = 279,
		['pupilExp'] = 27900,
	},
	['280']={
		['pupilLv'] = 280,
		['pupilExp'] = 28000,
	},
	['281']={
		['pupilLv'] = 281,
		['pupilExp'] = 28100,
	},
	['282']={
		['pupilLv'] = 282,
		['pupilExp'] = 28200,
	},
	['283']={
		['pupilLv'] = 283,
		['pupilExp'] = 28300,
	},
	['284']={
		['pupilLv'] = 284,
		['pupilExp'] = 28400,
	},
	['285']={
		['pupilLv'] = 285,
		['pupilExp'] = 28500,
	},
	['286']={
		['pupilLv'] = 286,
		['pupilExp'] = 28600,
	},
	['287']={
		['pupilLv'] = 287,
		['pupilExp'] = 28700,
	},
	['288']={
		['pupilLv'] = 288,
		['pupilExp'] = 28800,
	},
	['289']={
		['pupilLv'] = 289,
		['pupilExp'] = 28900,
	},
	['290']={
		['pupilLv'] = 290,
		['pupilExp'] = 29000,
	},
	['291']={
		['pupilLv'] = 291,
		['pupilExp'] = 29100,
	},
	['292']={
		['pupilLv'] = 292,
		['pupilExp'] = 29200,
	},
	['293']={
		['pupilLv'] = 293,
		['pupilExp'] = 29300,
	},
	['294']={
		['pupilLv'] = 294,
		['pupilExp'] = 29400,
	},
	['295']={
		['pupilLv'] = 295,
		['pupilExp'] = 29500,
	},
	['296']={
		['pupilLv'] = 296,
		['pupilExp'] = 29600,
	},
	['297']={
		['pupilLv'] = 297,
		['pupilExp'] = 29700,
	},
	['298']={
		['pupilLv'] = 298,
		['pupilExp'] = 29800,
	},
	['299']={
		['pupilLv'] = 299,
		['pupilExp'] = 29900,
	},
	['300']={
		['pupilLv'] = 300,
		['pupilExp'] = 30000,
	},
};