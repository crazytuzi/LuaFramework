ChjuanxianConfig={
	['1']={
		['id'] = 1,
		['item'] = 140633159,
		['reward'] = "14,5000",
		['progress'] = 5,
	},
	['2']={
		['id'] = 2,
		['item'] = 140633156,
		['reward'] = "14,10000",
		['progress'] = 10,
	},
	['3']={
		['id'] = 3,
		['item'] = 140633155,
		['reward'] = "14,25000",
		['progress'] = 25,
	},
	['4']={
		['id'] = 4,
		['item'] = 140633154,
		['reward'] = "14,50000",
		['progress'] = 50,
	},
};