TianshenConfig={
	['1']={
		['id'] = 1,
		['act_level'] = 35,
		['act_item'] = {151800001,1},
		['mode'] = 1,
	},
	['2']={
		['id'] = 2,
		['act_level'] = 35,
		['act_item'] = {151800002,1},
		['mode'] = 1,
	},
	['7']={
		['id'] = 7,
		['act_level'] = 35,
		['act_item'] = {151800009,1},
		['mode'] = 1,
	},
	['10']={
		['id'] = 10,
		['act_level'] = 35,
		['act_item'] = {151800004,1},
		['mode'] = 1,
	},
	['11']={
		['id'] = 11,
		['act_level'] = 35,
		['act_item'] = {151800006,1},
		['mode'] = 1,
	},
	['6']={
		['id'] = 6,
		['act_level'] = 35,
		['act_item'] = {151800010,1},
		['mode'] = 1,
	},
	['5']={
		['id'] = 5,
		['act_level'] = 35,
		['act_item'] = {151800008,1},
		['mode'] = 1,
	},
};