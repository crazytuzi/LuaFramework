Randomitem1Config={
	['1']={
		['level'] = 1,
		['weight1'] = 1000,
	},
	['2']={
		['level'] = 2,
		['weight1'] = 1000,
	},
	['3']={
		['level'] = 3,
		['weight1'] = 1000,
	},
	['4']={
		['level'] = 4,
		['weight1'] = 1000,
	},
	['5']={
		['level'] = 5,
		['weight1'] = 1000,
	},
	['6']={
		['level'] = 6,
		['weight1'] = 1000,
	},
	['7']={
		['level'] = 7,
		['weight1'] = 1000,
	},
	['8']={
		['level'] = 8,
		['weight1'] = 1000,
	},
	['9']={
		['level'] = 9,
		['weight1'] = 1000,
	},
	['10']={
		['level'] = 10,
		['weight1'] = 1000,
	},
	['11']={
		['level'] = 11,
		['weight1'] = 1000,
	},
	['12']={
		['level'] = 12,
		['weight1'] = 1000,
	},
};