SwyjmontneumConfig={
	['1']={
		['id'] = 1,
		['elitemont'] = 8,
		['mapid'] = 11401001,
	},
	['2']={
		['id'] = 2,
		['elitemont'] = 8,
		['mapid'] = 11401002,
	},
	['3']={
		['id'] = 3,
		['elitemont'] = 8,
		['mapid'] = 11401003,
	},
	['4']={
		['id'] = 4,
		['elitemont'] = 8,
		['mapid'] = 11401004,
	},
	['5']={
		['id'] = 5,
		['elitemont'] = 8,
		['mapid'] = 11401005,
	},
	['6']={
		['id'] = 6,
		['elitemont'] = 8,
		['mapid'] = 11401006,
	},
};