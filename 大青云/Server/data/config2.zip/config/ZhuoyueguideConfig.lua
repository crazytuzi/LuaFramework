ZhuoyueguideConfig={
	['1']={
		['id'] = 1,
		['superNum'] = 2,
		['equipNum'] = 11,
		['nextId'] = 2,
		['reward'] = "7,100000000#14,500000",
	},
	['2']={
		['id'] = 2,
		['superNum'] = 3,
		['equipNum'] = 11,
		['nextId'] = 0,
		['reward'] = "7,300000000#14,1000000",
	},
};