ChjuanxianrewardConfig={
	['1']={
		['id'] = 1,
		['percent'] = 30,
		['reward'] = "140649201,1",
	},
	['2']={
		['id'] = 2,
		['percent'] = 50,
		['reward'] = "140649202,1",
	},
	['3']={
		['id'] = 3,
		['percent'] = 80,
		['reward'] = "140649203,1",
	},
	['4']={
		['id'] = 4,
		['percent'] = 100,
		['reward'] = "140649204,1",
	},
};