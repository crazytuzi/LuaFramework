GuildprayConfig={
	['1']={
		['id'] = 1,
		['cost_type'] = 10,
		['cost_count'] = 10000,
		['huoyuedu'] = 10,
		['banggong'] = 10,
		['num'] = 1,
	},
	['2']={
		['id'] = 2,
		['cost_type'] = 12,
		['cost_count'] = 5,
		['huoyuedu'] = 50,
		['banggong'] = 50,
		['num'] = 1,
	},
	['3']={
		['id'] = 3,
		['cost_type'] = 12,
		['cost_count'] = 100,
		['huoyuedu'] = 1000,
		['banggong'] = 1000,
		['num'] = 1,
	},
};