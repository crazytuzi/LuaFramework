FashiongroupConfig={
	['1']={
		['id'] = 1,
		['Attr'] = "att,120#def,60#hp,1200",
	},
	['2']={
		['id'] = 2,
		['Attr'] = "att,600#def,300#hp,6000#hit,1150#dodge,1150",
	},
	['3']={
		['id'] = 3,
		['Attr'] = "att,600#def,400#hp,2400",
	},
	['4']={
		['id'] = 4,
		['Attr'] = "att,750#def,500#hp,3000",
	},
	['5']={
		['id'] = 5,
		['Attr'] = "att,750#def,500#hp,3000",
	},
	['6']={
		['id'] = 6,
		['Attr'] = "att,150#def,100#hp,600",
	},
	['7']={
		['id'] = 7,
		['Attr'] = "att,500#def,300#hp,2000",
	},
};