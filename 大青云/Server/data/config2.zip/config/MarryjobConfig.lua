MarryjobConfig={
	['6']={
		['carId'] = 6,
		['women'] = 1,
		['man'] = 3,
	},
	['7']={
		['carId'] = 7,
		['women'] = 4,
		['man'] = 2,
	},
	['8']={
		['carId'] = 8,
		['women'] = 4,
		['man'] = 3,
	},
	['9']={
		['carId'] = 9,
		['women'] = 1,
		['man'] = 2,
	},
};