GuildskillgroudConfig={
	['1']={
		['id'] = 1,
		['need_guildlv'] = 1,
	},
	['2']={
		['id'] = 2,
		['need_guildlv'] = 2,
	},
	['3']={
		['id'] = 3,
		['need_guildlv'] = 3,
	},
	['4']={
		['id'] = 4,
		['need_guildlv'] = 4,
	},
	['5']={
		['id'] = 5,
		['need_guildlv'] = 5,
	},
	['6']={
		['id'] = 6,
		['need_guildlv'] = 6,
	},
	['7']={
		['id'] = 7,
		['need_guildlv'] = 7,
	},
	['8']={
		['id'] = 8,
		['need_guildlv'] = 8,
	},
};