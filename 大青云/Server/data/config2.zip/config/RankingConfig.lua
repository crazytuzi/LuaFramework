RankingConfig={
	['1']={
		['id'] = 1,
		['condition'] = 1,
		['content'] = 70,
	},
	['2']={
		['id'] = 2,
		['condition'] = 2,
		['content'] = 10000,
	},
	['3']={
		['id'] = 3,
		['condition'] = 3,
		['content'] = 2,
	},
	['4']={
		['id'] = 4,
		['condition'] = 3,
		['content'] = 2,
	},
	['5']={
		['id'] = 5,
		['condition'] = 0,
		['content'] = 0,
	},
	['6']={
		['id'] = 6,
		['condition'] = 0,
		['content'] = 0,
	},
	['7']={
		['id'] = 7,
		['condition'] = 0,
		['content'] = 0,
	},
	['8']={
		['id'] = 8,
		['condition'] = 0,
		['content'] = 0,
	},
	['9']={
		['id'] = 9,
		['condition'] = 3,
		['content'] = 2,
	},
	['10']={
		['id'] = 10,
		['condition'] = 3,
		['content'] = 2,
	},
	['11']={
		['id'] = 11,
		['condition'] = 3,
		['content'] = 2,
	},
	['12']={
		['id'] = 12,
		['condition'] = 3,
		['content'] = 2,
	},
	['13']={
		['id'] = 13,
		['condition'] = 3,
		['content'] = 2,
	},
};