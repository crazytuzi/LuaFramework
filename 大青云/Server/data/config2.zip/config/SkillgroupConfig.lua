SkillgroupConfig={
	['1001']={
		['id'] = 1001,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['1002']={
		['id'] = 1002,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1003']={
		['id'] = 1003,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1004']={
		['id'] = 1004,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1005']={
		['id'] = 1005,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1006']={
		['id'] = 1006,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1007']={
		['id'] = 1007,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1008']={
		['id'] = 1008,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1009']={
		['id'] = 1009,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['1010']={
		['id'] = 1010,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['1011']={
		['id'] = 1011,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['1012']={
		['id'] = 1012,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['1013']={
		['id'] = 1013,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['1014']={
		['id'] = 1014,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['1015']={
		['id'] = 1015,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['1016']={
		['id'] = 1016,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['1017']={
		['id'] = 1017,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['1018']={
		['id'] = 1018,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2001']={
		['id'] = 2001,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['2002']={
		['id'] = 2002,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2003']={
		['id'] = 2003,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2004']={
		['id'] = 2004,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2005']={
		['id'] = 2005,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2006']={
		['id'] = 2006,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2007']={
		['id'] = 2007,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2008']={
		['id'] = 2008,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2009']={
		['id'] = 2009,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['2010']={
		['id'] = 2010,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['2011']={
		['id'] = 2011,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['2012']={
		['id'] = 2012,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2013']={
		['id'] = 2013,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2014']={
		['id'] = 2014,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2015']={
		['id'] = 2015,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2016']={
		['id'] = 2016,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2017']={
		['id'] = 2017,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['2018']={
		['id'] = 2018,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3001']={
		['id'] = 3001,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['3002']={
		['id'] = 3002,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3003']={
		['id'] = 3003,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3004']={
		['id'] = 3004,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3005']={
		['id'] = 3005,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3006']={
		['id'] = 3006,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3007']={
		['id'] = 3007,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3008']={
		['id'] = 3008,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3009']={
		['id'] = 3009,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['3010']={
		['id'] = 3010,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['3011']={
		['id'] = 3011,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['3012']={
		['id'] = 3012,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3013']={
		['id'] = 3013,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3014']={
		['id'] = 3014,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3015']={
		['id'] = 3015,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3016']={
		['id'] = 3016,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3017']={
		['id'] = 3017,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['3018']={
		['id'] = 3018,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4001']={
		['id'] = 4001,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['4002']={
		['id'] = 4002,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['4003']={
		['id'] = 4003,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['4004']={
		['id'] = 4004,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['4005']={
		['id'] = 4005,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['4006']={
		['id'] = 4006,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['4007']={
		['id'] = 4007,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['4008']={
		['id'] = 4008,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['4009']={
		['id'] = 4009,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['4010']={
		['id'] = 4010,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['4011']={
		['id'] = 4011,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['4012']={
		['id'] = 4012,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4013']={
		['id'] = 4013,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4014']={
		['id'] = 4014,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4015']={
		['id'] = 4015,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4016']={
		['id'] = 4016,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4017']={
		['id'] = 4017,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4018']={
		['id'] = 4018,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['4019']={
		['id'] = 4019,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['5001']={
		['id'] = 5001,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5002']={
		['id'] = 5002,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5003']={
		['id'] = 5003,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5004']={
		['id'] = 5004,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5005']={
		['id'] = 5005,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5006']={
		['id'] = 5006,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5007']={
		['id'] = 5007,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5008']={
		['id'] = 5008,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5009']={
		['id'] = 5009,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['5010']={
		['id'] = 5010,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['5011']={
		['id'] = 5011,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['7001']={
		['id'] = 7001,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7002']={
		['id'] = 7002,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7003']={
		['id'] = 7003,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7004']={
		['id'] = 7004,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7005']={
		['id'] = 7005,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7006']={
		['id'] = 7006,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7007']={
		['id'] = 7007,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7008']={
		['id'] = 7008,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7009']={
		['id'] = 7009,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7010']={
		['id'] = 7010,
		['maxLvl'] = 13,
		['stepGroup'] = 0,
	},
	['7011']={
		['id'] = 7011,
		['maxLvl'] = 120,
		['stepGroup'] = 0,
	},
	['8001']={
		['id'] = 8001,
		['maxLvl'] = 14,
		['stepGroup'] = 0,
	},
	['9001']={
		['id'] = 9001,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['10001']={
		['id'] = 10001,
		['maxLvl'] = 12,
		['stepGroup'] = 0,
	},
	['10301']={
		['id'] = 10301,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['10401']={
		['id'] = 10401,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['10501']={
		['id'] = 10501,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['10901']={
		['id'] = 10901,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10902']={
		['id'] = 10902,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10903']={
		['id'] = 10903,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10904']={
		['id'] = 10904,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10905']={
		['id'] = 10905,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10906']={
		['id'] = 10906,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10907']={
		['id'] = 10907,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['10908']={
		['id'] = 10908,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['11102']={
		['id'] = 11102,
		['maxLvl'] = 6,
		['stepGroup'] = 0,
	},
	['11103']={
		['id'] = 11103,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['11104']={
		['id'] = 11104,
		['maxLvl'] = 4,
		['stepGroup'] = 0,
	},
	['11105']={
		['id'] = 11105,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['11106']={
		['id'] = 11106,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['11101']={
		['id'] = 11101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['11201']={
		['id'] = 11201,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['11301']={
		['id'] = 11301,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['11401']={
		['id'] = 11401,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['11501']={
		['id'] = 11501,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['11601']={
		['id'] = 11601,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['11701']={
		['id'] = 11701,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['11801']={
		['id'] = 11801,
		['maxLvl'] = 0,
		['stepGroup'] = 0,
	},
	['11901']={
		['id'] = 11901,
		['maxLvl'] = 0,
		['stepGroup'] = 0,
	},
	['12101']={
		['id'] = 12101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['12201']={
		['id'] = 12201,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['12301']={
		['id'] = 12301,
		['maxLvl'] = 8,
		['stepGroup'] = 0,
	},
	['12401']={
		['id'] = 12401,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['12501']={
		['id'] = 12501,
		['maxLvl'] = 6,
		['stepGroup'] = 0,
	},
	['12601']={
		['id'] = 12601,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['12701']={
		['id'] = 12701,
		['maxLvl'] = 4,
		['stepGroup'] = 0,
	},
	['12801']={
		['id'] = 12801,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['12901']={
		['id'] = 12901,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['12902']={
		['id'] = 12902,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['12903']={
		['id'] = 12903,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['12904']={
		['id'] = 12904,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['12905']={
		['id'] = 12905,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['12906']={
		['id'] = 12906,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['12907']={
		['id'] = 12907,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13001']={
		['id'] = 13001,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['13002']={
		['id'] = 13002,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['13003']={
		['id'] = 13003,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['13004']={
		['id'] = 13004,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['13005']={
		['id'] = 13005,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['13006']={
		['id'] = 13006,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13101']={
		['id'] = 13101,
		['maxLvl'] = 6,
		['stepGroup'] = 0,
	},
	['13201']={
		['id'] = 13201,
		['maxLvl'] = 8,
		['stepGroup'] = 0,
	},
	['13301']={
		['id'] = 13301,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['13401']={
		['id'] = 13401,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['13501']={
		['id'] = 13501,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13601']={
		['id'] = 13601,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13701']={
		['id'] = 13701,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13801']={
		['id'] = 13801,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13901']={
		['id'] = 13901,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13111']={
		['id'] = 13111,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13121']={
		['id'] = 13121,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['13131']={
		['id'] = 13131,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['14101']={
		['id'] = 14101,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['14201']={
		['id'] = 14201,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['14301']={
		['id'] = 14301,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['14401']={
		['id'] = 14401,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['14501']={
		['id'] = 14501,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['14601']={
		['id'] = 14601,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['14701']={
		['id'] = 14701,
		['maxLvl'] = 0,
		['stepGroup'] = 0,
	},
	['15101']={
		['id'] = 15101,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15201']={
		['id'] = 15201,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15301']={
		['id'] = 15301,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15401']={
		['id'] = 15401,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15501']={
		['id'] = 15501,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15601']={
		['id'] = 15601,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15701']={
		['id'] = 15701,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['15801']={
		['id'] = 15801,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['16101']={
		['id'] = 16101,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['16201']={
		['id'] = 16201,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['16301']={
		['id'] = 16301,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['16401']={
		['id'] = 16401,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['16501']={
		['id'] = 16501,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['16601']={
		['id'] = 16601,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['16701']={
		['id'] = 16701,
		['maxLvl'] = 20,
		['stepGroup'] = 0,
	},
	['17101']={
		['id'] = 17101,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17201']={
		['id'] = 17201,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17301']={
		['id'] = 17301,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17401']={
		['id'] = 17401,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17501']={
		['id'] = 17501,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17601']={
		['id'] = 17601,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17701']={
		['id'] = 17701,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17801']={
		['id'] = 17801,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['17901']={
		['id'] = 17901,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['171001']={
		['id'] = 171001,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['171101']={
		['id'] = 171101,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['171201']={
		['id'] = 171201,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['18101']={
		['id'] = 18101,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['18201']={
		['id'] = 18201,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['18301']={
		['id'] = 18301,
		['maxLvl'] = 4,
		['stepGroup'] = 0,
	},
	['18401']={
		['id'] = 18401,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['18501']={
		['id'] = 18501,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['18601']={
		['id'] = 18601,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['18701']={
		['id'] = 18701,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['18801']={
		['id'] = 18801,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['19101']={
		['id'] = 19101,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['19201']={
		['id'] = 19201,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['19301']={
		['id'] = 19301,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['19401']={
		['id'] = 19401,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['19501']={
		['id'] = 19501,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['19601']={
		['id'] = 19601,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['19701']={
		['id'] = 19701,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['19801']={
		['id'] = 19801,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['19901']={
		['id'] = 19901,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['20101']={
		['id'] = 20101,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['20102']={
		['id'] = 20102,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['20201']={
		['id'] = 20201,
		['maxLvl'] = 11,
		['stepGroup'] = 0,
	},
	['21101']={
		['id'] = 21101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['21201']={
		['id'] = 21201,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['21301']={
		['id'] = 21301,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['21401']={
		['id'] = 21401,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['21501']={
		['id'] = 21501,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['22101']={
		['id'] = 22101,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['22201']={
		['id'] = 22201,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['22301']={
		['id'] = 22301,
		['maxLvl'] = 4,
		['stepGroup'] = 0,
	},
	['23101']={
		['id'] = 23101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['23201']={
		['id'] = 23201,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['23301']={
		['id'] = 23301,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['23401']={
		['id'] = 23401,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['23501']={
		['id'] = 23501,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['24101']={
		['id'] = 24101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['24201']={
		['id'] = 24201,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['24301']={
		['id'] = 24301,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['24401']={
		['id'] = 24401,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['24501']={
		['id'] = 24501,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['25101']={
		['id'] = 25101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['25201']={
		['id'] = 25201,
		['maxLvl'] = 8,
		['stepGroup'] = 0,
	},
	['25301']={
		['id'] = 25301,
		['maxLvl'] = 6,
		['stepGroup'] = 0,
	},
	['25401']={
		['id'] = 25401,
		['maxLvl'] = 4,
		['stepGroup'] = 0,
	},
	['25501']={
		['id'] = 25501,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['25601']={
		['id'] = 25601,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['25701']={
		['id'] = 25701,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['26101']={
		['id'] = 26101,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26102']={
		['id'] = 26102,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26103']={
		['id'] = 26103,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26104']={
		['id'] = 26104,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26201']={
		['id'] = 26201,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26202']={
		['id'] = 26202,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26203']={
		['id'] = 26203,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26204']={
		['id'] = 26204,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26301']={
		['id'] = 26301,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26302']={
		['id'] = 26302,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26303']={
		['id'] = 26303,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26304']={
		['id'] = 26304,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26401']={
		['id'] = 26401,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26402']={
		['id'] = 26402,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26403']={
		['id'] = 26403,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26404']={
		['id'] = 26404,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26501']={
		['id'] = 26501,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26502']={
		['id'] = 26502,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26503']={
		['id'] = 26503,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['26504']={
		['id'] = 26504,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27001']={
		['id'] = 27001,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27002']={
		['id'] = 27002,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27003']={
		['id'] = 27003,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27004']={
		['id'] = 27004,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27005']={
		['id'] = 27005,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27006']={
		['id'] = 27006,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27007']={
		['id'] = 27007,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27011']={
		['id'] = 27011,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27012']={
		['id'] = 27012,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27013']={
		['id'] = 27013,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27014']={
		['id'] = 27014,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27015']={
		['id'] = 27015,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27016']={
		['id'] = 27016,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27017']={
		['id'] = 27017,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27018']={
		['id'] = 27018,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27019']={
		['id'] = 27019,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27020']={
		['id'] = 27020,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27021']={
		['id'] = 27021,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27022']={
		['id'] = 27022,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27023']={
		['id'] = 27023,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27024']={
		['id'] = 27024,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27025']={
		['id'] = 27025,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27026']={
		['id'] = 27026,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27027']={
		['id'] = 27027,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27028']={
		['id'] = 27028,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27029']={
		['id'] = 27029,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27030']={
		['id'] = 27030,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27031']={
		['id'] = 27031,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27032']={
		['id'] = 27032,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27033']={
		['id'] = 27033,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27101']={
		['id'] = 27101,
		['maxLvl'] = 10,
		['stepGroup'] = 0,
	},
	['27102']={
		['id'] = 27102,
		['maxLvl'] = 9,
		['stepGroup'] = 0,
	},
	['27103']={
		['id'] = 27103,
		['maxLvl'] = 7,
		['stepGroup'] = 0,
	},
	['27104']={
		['id'] = 27104,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['27105']={
		['id'] = 27105,
		['maxLvl'] = 3,
		['stepGroup'] = 0,
	},
	['27106']={
		['id'] = 27106,
		['maxLvl'] = 2,
		['stepGroup'] = 0,
	},
	['27107']={
		['id'] = 27107,
		['maxLvl'] = 1,
		['stepGroup'] = 0,
	},
	['27108']={
		['id'] = 27108,
		['maxLvl'] = 0,
		['stepGroup'] = 0,
	},
	['28001']={
		['id'] = 28001,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28002']={
		['id'] = 28002,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28003']={
		['id'] = 28003,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28004']={
		['id'] = 28004,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28005']={
		['id'] = 28005,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28006']={
		['id'] = 28006,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28007']={
		['id'] = 28007,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28101']={
		['id'] = 28101,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28102']={
		['id'] = 28102,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28103']={
		['id'] = 28103,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28104']={
		['id'] = 28104,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28105']={
		['id'] = 28105,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28106']={
		['id'] = 28106,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28107']={
		['id'] = 28107,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28108']={
		['id'] = 28108,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28109']={
		['id'] = 28109,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28110']={
		['id'] = 28110,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28111']={
		['id'] = 28111,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28201']={
		['id'] = 28201,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28202']={
		['id'] = 28202,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28203']={
		['id'] = 28203,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28204']={
		['id'] = 28204,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28205']={
		['id'] = 28205,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28206']={
		['id'] = 28206,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28207']={
		['id'] = 28207,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28301']={
		['id'] = 28301,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28302']={
		['id'] = 28302,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28303']={
		['id'] = 28303,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28304']={
		['id'] = 28304,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28305']={
		['id'] = 28305,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28306']={
		['id'] = 28306,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28307']={
		['id'] = 28307,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28401']={
		['id'] = 28401,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28402']={
		['id'] = 28402,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28403']={
		['id'] = 28403,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28404']={
		['id'] = 28404,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28405']={
		['id'] = 28405,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28406']={
		['id'] = 28406,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28407']={
		['id'] = 28407,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28501']={
		['id'] = 28501,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28502']={
		['id'] = 28502,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28503']={
		['id'] = 28503,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28504']={
		['id'] = 28504,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28505']={
		['id'] = 28505,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28506']={
		['id'] = 28506,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28507']={
		['id'] = 28507,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28601']={
		['id'] = 28601,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28602']={
		['id'] = 28602,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28603']={
		['id'] = 28603,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28604']={
		['id'] = 28604,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28605']={
		['id'] = 28605,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28606']={
		['id'] = 28606,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28607']={
		['id'] = 28607,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28701']={
		['id'] = 28701,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28702']={
		['id'] = 28702,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28703']={
		['id'] = 28703,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28704']={
		['id'] = 28704,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28705']={
		['id'] = 28705,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28706']={
		['id'] = 28706,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28707']={
		['id'] = 28707,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28801']={
		['id'] = 28801,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28802']={
		['id'] = 28802,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28803']={
		['id'] = 28803,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28804']={
		['id'] = 28804,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28805']={
		['id'] = 28805,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28806']={
		['id'] = 28806,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
	['28807']={
		['id'] = 28807,
		['maxLvl'] = 5,
		['stepGroup'] = 0,
	},
};