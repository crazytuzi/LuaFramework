ItemcompoundConfig={
	['151100042']={
		['id'] = 151100042,
		['materialitem'] = "151100041,5",
		['consume_money'] = 100,
	},
	['151100043']={
		['id'] = 151100043,
		['materialitem'] = "151100042,5",
		['consume_money'] = 200,
	},
	['151100044']={
		['id'] = 151100044,
		['materialitem'] = "151100043,5",
		['consume_money'] = 200,
	},
	['151100052']={
		['id'] = 151100052,
		['materialitem'] = "151100051,5",
		['consume_money'] = 500,
	},
	['151100053']={
		['id'] = 151100053,
		['materialitem'] = "151100052,5",
		['consume_money'] = 100,
	},
	['151100054']={
		['id'] = 151100054,
		['materialitem'] = "151100053,5",
		['consume_money'] = 100,
	},
	['151100062']={
		['id'] = 151100062,
		['materialitem'] = "151100061,5",
		['consume_money'] = 200,
	},
	['151100063']={
		['id'] = 151100063,
		['materialitem'] = "151100062,5",
		['consume_money'] = 500,
	},
	['151100064']={
		['id'] = 151100064,
		['materialitem'] = "151100063,5",
		['consume_money'] = 500,
	},
	['150100002']={
		['id'] = 150100002,
		['materialitem'] = "150100001,5",
		['consume_money'] = 1000,
	},
	['110120027']={
		['id'] = 110120027,
		['materialitem'] = "110120026,5",
		['consume_money'] = 1000,
	},
	['110120028']={
		['id'] = 110120028,
		['materialitem'] = "110120027,5",
		['consume_money'] = 1000,
	},
};