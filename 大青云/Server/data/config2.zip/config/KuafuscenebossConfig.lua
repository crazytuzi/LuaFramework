KuafuscenebossConfig={
	['14000011']={
		['bossId'] = 14000011,
		['sence'] = 1,
		['score'] = 0,
	},
	['14000012']={
		['bossId'] = 14000012,
		['sence'] = 1,
		['score'] = 0,
	},
	['14000013']={
		['bossId'] = 14000013,
		['sence'] = 1,
		['score'] = 0,
	},
};