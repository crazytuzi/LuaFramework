HomepupilimageConfig={
	['1']={
		['id'] = 1,
		['image_man'] = "pupil_man_1",
	},
	['2']={
		['id'] = 2,
		['image_man'] = "pupil_man_2",
	},
	['3']={
		['id'] = 3,
		['image_man'] = "pupil_man_3",
	},
	['4']={
		['id'] = 4,
		['image_man'] = "pupil_man_4",
	},
	['5']={
		['id'] = 5,
		['image_man'] = "pupil_man_5",
	},
	['6']={
		['id'] = 6,
		['image_man'] = "pupil_man_6",
	},
	['7']={
		['id'] = 7,
		['image_man'] = "pupil_man_7",
	},
	['8']={
		['id'] = 8,
		['image_man'] = "pupil_man_8",
	},
	['9']={
		['id'] = 9,
		['image_man'] = "pupil_man_9",
	},
	['10']={
		['id'] = 10,
		['image_man'] = "pupil_man_10",
	},
	['11']={
		['id'] = 11,
		['image_man'] = "pupil_man_11",
	},
	['12']={
		['id'] = 12,
		['image_man'] = "pupil_man_12",
	},
	['13']={
		['id'] = 13,
		['image_man'] = "pupil_man_13",
	},
	['14']={
		['id'] = 14,
		['image_man'] = "pupil_man_14",
	},
	['15']={
		['id'] = 15,
		['image_man'] = "pupil_man_15",
	},
	['16']={
		['id'] = 16,
		['image_man'] = "pupil_man_16",
	},
	['17']={
		['id'] = 17,
		['image_man'] = "pupil_man_17",
	},
	['18']={
		['id'] = 18,
		['image_man'] = "pupil_man_18",
	},
	['19']={
		['id'] = 19,
		['image_man'] = "pupil_man_19",
	},
	['20']={
		['id'] = 20,
		['image_man'] = "pupil_man_20",
	},
	['21']={
		['id'] = 21,
		['image_man'] = "pupil_man_21",
	},
	['22']={
		['id'] = 22,
		['image_man'] = "pupil_man_22",
	},
	['23']={
		['id'] = 23,
		['image_man'] = "pupil_man_23",
	},
	['24']={
		['id'] = 24,
		['image_man'] = "pupil_man_24",
	},
	['25']={
		['id'] = 25,
		['image_man'] = "pupil_man_25",
	},
	['101']={
		['id'] = 101,
		['image_man'] = "pupil_woman_1",
	},
	['102']={
		['id'] = 102,
		['image_man'] = "pupil_woman_2",
	},
	['103']={
		['id'] = 103,
		['image_man'] = "pupil_woman_3",
	},
	['104']={
		['id'] = 104,
		['image_man'] = "pupil_woman_4",
	},
	['105']={
		['id'] = 105,
		['image_man'] = "pupil_woman_5",
	},
	['106']={
		['id'] = 106,
		['image_man'] = "pupil_woman_6",
	},
	['107']={
		['id'] = 107,
		['image_man'] = "pupil_woman_7",
	},
	['108']={
		['id'] = 108,
		['image_man'] = "pupil_woman_8",
	},
	['109']={
		['id'] = 109,
		['image_man'] = "pupil_woman_9",
	},
	['110']={
		['id'] = 110,
		['image_man'] = "pupil_woman_10",
	},
	['111']={
		['id'] = 111,
		['image_man'] = "pupil_woman_11",
	},
	['112']={
		['id'] = 112,
		['image_man'] = "pupil_woman_12",
	},
	['113']={
		['id'] = 113,
		['image_man'] = "pupil_woman_13",
	},
	['114']={
		['id'] = 114,
		['image_man'] = "pupil_woman_14",
	},
	['115']={
		['id'] = 115,
		['image_man'] = "pupil_woman_15",
	},
	['116']={
		['id'] = 116,
		['image_man'] = "pupil_woman_16",
	},
	['117']={
		['id'] = 117,
		['image_man'] = "pupil_woman_17",
	},
	['118']={
		['id'] = 118,
		['image_man'] = "pupil_woman_18",
	},
	['119']={
		['id'] = 119,
		['image_man'] = "pupil_woman_19",
	},
	['120']={
		['id'] = 120,
		['image_man'] = "pupil_woman_20",
	},
	['121']={
		['id'] = 121,
		['image_man'] = "pupil_woman_21",
	},
	['122']={
		['id'] = 122,
		['image_man'] = "pupil_woman_22",
	},
	['123']={
		['id'] = 123,
		['image_man'] = "pupil_woman_23",
	},
	['124']={
		['id'] = 124,
		['image_man'] = "pupil_woman_24",
	},
};