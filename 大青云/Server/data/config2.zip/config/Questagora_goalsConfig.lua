Questagora_goalsConfig={
	['1001']={
		['id'] = 1001,
		['quality'] = 1,
		['kind'] = 3,
		['questGoals'] = "1",
	},
	['1002']={
		['id'] = 1002,
		['quality'] = 1,
		['kind'] = 3,
		['questGoals'] = "1",
	},
	['1003']={
		['id'] = 1003,
		['quality'] = 2,
		['kind'] = 3,
		['questGoals'] = "1",
	},
	['1004']={
		['id'] = 1004,
		['quality'] = 2,
		['kind'] = 3,
		['questGoals'] = "1",
	},
	['1005']={
		['id'] = 1005,
		['quality'] = 3,
		['kind'] = 3,
		['questGoals'] = "1",
	},
	['1006']={
		['id'] = 1006,
		['quality'] = 3,
		['kind'] = 3,
		['questGoals'] = "1",
	},
};