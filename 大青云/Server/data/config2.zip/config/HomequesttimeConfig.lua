HomequesttimeConfig={
	['1']={
		['id'] = 1,
		['rate'] = 100,
		['time'] = 300,
		['questRewardTimeAdd'] = 10,
	},
	['2']={
		['id'] = 2,
		['rate'] = 100,
		['time'] = 600,
		['questRewardTimeAdd'] = 18,
	},
	['3']={
		['id'] = 3,
		['rate'] = 100,
		['time'] = 900,
		['questRewardTimeAdd'] = 24,
	},
	['4']={
		['id'] = 4,
		['rate'] = 100,
		['time'] = 1200,
		['questRewardTimeAdd'] = 29,
	},
	['5']={
		['id'] = 5,
		['rate'] = 100,
		['time'] = 1800,
		['questRewardTimeAdd'] = 39,
	},
	['6']={
		['id'] = 6,
		['rate'] = 100,
		['time'] = 3600,
		['questRewardTimeAdd'] = 72,
	},
	['7']={
		['id'] = 7,
		['rate'] = 100,
		['time'] = 5400,
		['questRewardTimeAdd'] = 99,
	},
	['8']={
		['id'] = 8,
		['rate'] = 100,
		['time'] = 7200,
		['questRewardTimeAdd'] = 120,
	},
};