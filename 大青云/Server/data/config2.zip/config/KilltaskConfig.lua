KilltaskConfig={
	['1000']={
		['id'] = 1000,
		['level'] = 1,
		['addition_props'] = "att,5#def,3#hp,50",
	},
	['2000']={
		['id'] = 2000,
		['level'] = 2,
		['addition_props'] = "att,10#def,5#hp,70",
	},
	['5000']={
		['id'] = 5000,
		['level'] = 3,
		['addition_props'] = "att,15#def,8#hp,100",
	},
	['10000']={
		['id'] = 10000,
		['level'] = 4,
		['addition_props'] = "att,20#def,10#hp,120",
	},
	['20000000']={
		['id'] = 20000000,
		['level'] = 5,
		['addition_props'] = "att,25#def,50#hp,300",
	},
};