HorseskillConfig={
	['1010001001']={
		['id'] = 1010001001,
		['slot_id'] = 1,
		['level'] = 1,
		['need_order'] = 2,
	},
	['1010001003']={
		['id'] = 1010001003,
		['slot_id'] = 1,
		['level'] = 2,
		['need_order'] = 3,
	},
	['1010001002']={
		['id'] = 1010001002,
		['slot_id'] = 2,
		['level'] = 1,
		['need_order'] = 4,
	},
};